import { Component } from '@angular/core';
// import { LoginpopupService } from './shared/login.service';
import { LoginpopupService } from './shared/loginpopup.service';
@Component({
    selector   : 'app-root',
    templateUrl: './app.component.html',
    styleUrls  : ['./app.component.scss']
})

export class AppComponent
{
    showLoginPopup: boolean = false;

    constructor(private LoginpopupService: LoginpopupService) {}
  
    ngOnInit(): void {
      this.LoginpopupService.showLoginPopup$.subscribe((showPopup) => {
        this.showLoginPopup = showPopup;
      });
    }
  
    closeLoginPopup(): void {
      this.LoginpopupService.closeLoginPopup();
    }
}
