import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.scss']
})
export class MenubarComponent implements OnInit {
  categoryArr: any = [];
  cityArr: any = [];
  categoryArrMore: any = [];
  remainingData: any[] = [];
  itemsToShowInitially:number=6;
  startIndex: number = 0;
  
  constructor(public CompareclgService: CompareclgService, private _formBuilder: FormBuilder, private route: Router, private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.getCategoryList();
    this.getCityList();
  }
  showLess() {
    this.startIndex -= 10;
    // Ensure the startIndex doesn't go below 0
    if (this.startIndex < 0) {
      this.startIndex = 0;
    }
  }
  showMore() {
    this.startIndex += 10;
    // Ensure the startIndex doesn't go beyond the array length
    if (this.startIndex >= this.categoryArrMore.length) {
      this.startIndex = this.categoryArrMore.length - 10;
    }
  }
  getCategoryList() {
    this.CompareclgService.getCategoryForMenu().subscribe(res => {
      // console.log(res);
      this.categoryArr = res.response_data;
      this.categoryArrMore = this.categoryArr.slice(4);
      // this.remainingData=this.categoryArrMore.slice(6);
      console.log(this.categoryArrMore);
    })
  }

  getCityList() {
    this.CompareclgService.getCityList().subscribe(res => {
      // console.log(res);
      this.cityArr = res.data;

    })
  }

  getCourseDetails(){
    
  }

  // routerLink="/allCollegeList/{{city.id}}/{{item.id}}"
  getcolleges(catid: string, cityid: string): void{
    localStorage.setItem('categoryId',catid);
    localStorage.setItem('cityId',cityid);
    this.route.navigate(['/allCollegeList/menu',catid,cityid]);
    // window.location.reload();
    
  }
}
