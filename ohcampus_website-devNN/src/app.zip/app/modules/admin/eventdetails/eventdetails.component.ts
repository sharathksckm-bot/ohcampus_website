import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import { AuthService } from 'app/core/auth/auth.service';
import { LoginpopupService } from 'app/shared/loginpopup.service';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-eventdetails',
  templateUrl: './eventdetails.component.html',
  styleUrls: ['./eventdetails.component.scss']
})
export class EventdetailsComponent implements OnInit {
  @ViewChild('EnqFormNgForm') EnqFormNgForm: NgForm;

  eventId: any;
  EnqForm: FormGroup;
  showInquiryMsg: any;
  event_detailsArr: any = [];

  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,
    private _formBuilder: FormBuilder,
    public dialog: MatDialog,
    public authService: AuthService,
    public LoginpopupService: LoginpopupService,
  ) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.eventId = routeParams.eventId;

    this.EnqForm = this._formBuilder.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      phone_no: ['', Validators.required],
      message: ['', Validators.required],
    })
    this.getEventDetails();

  }

  onLoginButtonClick(): void {
    // Check if the user is not logged in, then open the login popup
    if (!this.authService.isLoggedIn()) {
      this.LoginpopupService.openLoginPopup();
    }
  }

  numberOnly(event): boolean {
    // console.log(event.target.value)
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }


  clearFormErrors(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((key) => {
      formGroup.get(key).setErrors(null);
    });
  }

  saveEnquiry() {
    this.CompareclgService.saveEnquiry(
      this.EnqForm.value.name,
      this.EnqForm.value.email,
      this.EnqForm.value.phone_no,
      this.EnqForm.value.message,
      this.eventId,
      'blogs'
    ).subscribe(res => {
      this.showInquiryMsg = res.response_message
      console.log(res);
      this.EnqFormNgForm.resetForm();
      // this.EnqForm.reset();
      // this.clearFormErrors(this.EnqForm);
    })
  }

  getEventDetails() {
    this.CompareclgService.getEventDetails(this.eventId).subscribe(res => {
      console.log(res);
      this.event_detailsArr = res.event_details;
    })
  }
}
