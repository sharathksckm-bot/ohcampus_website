import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import { param } from 'jquery';

@Component({
  selector: 'app-exams',
  templateUrl: './exams.component.html',
  styleUrls: ['./exams.component.scss']
})
export class ExamsComponent implements OnInit {

  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;

  SearchExamForm: FormGroup;
  SearchArticleForm: FormGroup;
  examListArr: any = [];
  articlesArr: any = [];
  itemsToShow: number = 10;
  ArticlesToShow: number = 10;
  activeTabIndex: number = 0;
  activeTab: string;
  ExamLoader: boolean = false;
  ArticleLoader: boolean = false;
  // showShare:boolean=false;
  showShare: boolean[] = [];
  searchCategory = '';
  notification: any;
  searchexam: any;
  searchedexam: any;
  searchedarticle: any;

  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,) {
    this.examListArr.forEach(() => {
      this.showShare.push(false);
    });
  }

  ngOnInit(): void {

    this.SearchExamForm = this._formBuilder.group({
      searchexamtext: ['']
    }),

      this.SearchArticleForm = this._formBuilder.group({
        searchtext: ['']
      })

    const routeParams = this._activatedRoute.snapshot.params;
    console.log(routeParams);
    this.searchedexam = routeParams.searchedexam;
    this.searchedarticle = routeParams.searchedarticle;
    this.searchCategory = routeParams.blogcatid;

    // this.searchexam=routeParams.searchexam;
    if (this.searchCategory == undefined) {
      this.searchCategory = '';
    }
    // console.log(this.searchCategory)
    if (routeParams.tabno == 1) {
      this.activeTabIndex = 1;
    }

    if (this.searchedexam == undefined) {
      this.getExamList();
    }
    else {
      this.searchExamList()
    }

    if (this.searchedarticle == undefined) {
      this.getBlogs();
    }
    else {
      this.getArticleList()
    }


  }

  openDialog(notification) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.notification = notification;
  }

  close() {
    this.dialog.closeAll();
  }

  getExamList() {
    console.log(this.SearchExamForm.value.searchexamtext)
    this.ExamLoader = true;
    // this.SearchExamForm.value.searchtext=this.searchexam
    this.CompareclgService.getExamList(this.SearchExamForm.value.searchexamtext).subscribe(res => {
      // console.log(res);
      this.ExamLoader = false;
      this.examListArr = res.response_data;
    })
  }


  searchExamList() {
    // this.ExamLoader = true;
    this.CompareclgService.getExamList(this.searchedexam).subscribe(res => {
      // console.log(res);
      // this.ExamLoader = false;
      this.examListArr = res.response_data;
    })
  }

  getBlogs() {
    this.ArticleLoader = true;
    // this.searchCategory='';
    this.CompareclgService.getBlogsbyCat(this.searchCategory, this.SearchArticleForm.value.searchtext).subscribe(res => {
      // console.log(res);
      this.ArticleLoader = false;
      this.articlesArr = res.response_data;
    })
  }


  getArticleList() {
    // this.ArticleLoader = true;
    // this.searchCategory='';
    this.CompareclgService.getBlogsbyCat(this.searchCategory, this.searchedarticle).subscribe(res => {
      // console.log(res);
      // this.ArticleLoader = false;
      this.articlesArr = res.response_data;
    })
  }


  showMoreExams() {
    this.itemsToShow += 10;
  }

  showMoreArticles() {
    this.ArticlesToShow += 10;
  }

  toggleShare(index: number) {
    this.showShare[index] = !this.showShare[index];
  }

  getExamDetails(ExamId) {
    this.route.navigate(['/examsdetails', ExamId]);
  }

  getArticleDetails(BlogId) {
    this.route.navigate(['/articledetails', BlogId])
  }


}
