import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';

@Component({
  selector: 'app-scholarships',
  templateUrl: './scholarships.component.html',
  styleUrls: ['./scholarships.component.scss']
})
export class ScholarshipsComponent implements OnInit {

  searchSchlorshipForm:FormGroup;
  scholorshipArr:any=[];

  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,

  ) { }

  ngOnInit(): void {
    this.searchSchlorshipForm=this._formBuilder.group({
      searchvalue:['']
    })
    this.getScholarships();
  }

  getScholarships() {
    this.CompareclgService.getScholarships(this.searchSchlorshipForm.value.searchvalue).subscribe(res => {
      console.log(res);
      this.scholorshipArr=res.data;
    })
  }
}
