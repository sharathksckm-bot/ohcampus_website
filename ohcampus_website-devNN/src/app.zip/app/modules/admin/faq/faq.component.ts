import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatTabGroup } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {

  @ViewChild('tabGroup') tabGroup!: MatTabGroup;

  FaqCategoryArr: any = [];
  faqArr: any = [];

  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.getFaqCategory();
  }

  getFaqCategory() {
    this.CompareclgService.getFaqCategory().subscribe(res => {
      console.log(res);
      this.FaqCategoryArr = res.data;
    })
  }

  onTabChange(event) {
    const faqcategoryId = this.FaqCategoryArr[event].id;
    console.log(faqcategoryId)
    this.CompareclgService.getFaqs('', faqcategoryId).subscribe(res => {
      console.log(res)
      this.faqArr=res.data;
    })
  }

}
