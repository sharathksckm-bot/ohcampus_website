
import { Component, OnInit, ViewChild, TemplateRef, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import { MatTabGroup } from '@angular/material/tabs';
import { MatCheckbox } from '@angular/material/checkbox';
import { FormBuilder, FormGroup } from '@angular/forms';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-courses-and-fees',
  templateUrl: './courses-and-fees.component.html',
  styleUrls: ['./courses-and-fees.component.scss']
})
export class CoursesAndFeesComponent implements OnInit {
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  @ViewChild('popupFilter') popupFilter: TemplateRef<any>;
  @ViewChild('CourseFilter') CourseFilter: TemplateRef<any>;
  @Output() courseClicked = new EventEmitter<string>();
  // @Output() courseClicked: EventEmitter<string> = new EventEmitter<string>();
  //DECLARE FORMGROUPS
  filterForm: FormGroup;
  seachform: FormGroup;

  //DECLARE ARRAYS
  CoursesArr: any = [];
  popularProgramsFaqsArr: any = [];
  CoursesFeesFaqsArr: any = [];
  NotificationArr: any = [];
  campusImagesArr: any = [];
  courses_listArr: any = [];
  latest_blogsArr: any = [];
  popular_blogsArr: any = [];
  SameCourseInSameCityArr: any = [];
  SubCategoryArr: any = [];
  CourseLevelArr: any = [];
  ExamAcceptedArr: any = [];
  fees_listArr: any = [];

  //DECLARE VARIABLES
  FilterLoadercourse: boolean = false;
  FilterLoadercourselevel: boolean = false;
  FilterLoaderfees: boolean = false;
  image: any;
  cityid: any;
  collegeId: any;
  collegename: any;
  sub_category: string;
  subcatId: any;
  activeTabIndex: number = 0;
  CourseIntoTab: boolean = false;
  highest_fee: any;
  lowest_fee: any;
  courseid: any;
  fees: any;
  acceptedexam: any;
  CourseLeve: any;
  searchcourse: any;
  tab: number;

  constructor(
    public dialog: MatDialog,
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    public CompareclgService: CompareclgService,
    private tabGroup: MatTabGroup) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    this.subcatId = routeParams.subcatId;
    // console.log(this.subcatId)
    this.getCollegeDetailsByID();
    this.getCollegeProgrammesByID();
    this.getCoursesAndFeesOfClg();
    this.getExamNotificationForClg();
    // this.getCoursesOfCollege();
    this.getLatestBlogs();
    // this.getSubCategoryList();
    // this.getCourseLevel();
    // this.getExamAccepted();
    if (this.subcatId != undefined) {
      this.getCollegeProgrammesBySubCatID();

    }

    // this.getOtherCollegesOfferingSameCourseInSameCity();
    // this.sub_category = localStorage.getItem('sub_category');
    // console.log(this.sub_category)
    if (this.subcatId == undefined) {
      this.getCoursesOfCollege();
    }
    this.seachform = this.fb.group({
      searchCourse: ['']
    })
    this.filterForm = this.fb.group({
      course: [''],
      courselevel: [''],
      fees: [''],
      examAccepted: ['']
    })
    // this.filterForm.valueChanges.subscribe((formValues) => {
    //   // Handle form values as needed
    //   console.log('Form Values:', formValues);
    // });
  }

  openFilter(tab: string) {
    this.dialog.open(this.CourseFilter);
    this.filterForm.reset();
    switch (tab) {
      case 'courselevel':
        this.activeTabIndex = 1; // Index of the Course Level tab
        break;

      // case 'location':
      //   this.activeTabIndex = 2; 
      //   break;

      case 'totalfees':
        this.activeTabIndex = 2;
        break;

      default:
        this.activeTabIndex = 0; // Default to the first tab
        break;
    }
    this.getSubCategoryList();
    this.getCourseLevel();
    this.getExamAccepted();
    this.getFeesDataOfCollege();
  }

  ApplyFilter() {
    this.CompareclgService.getCoursesOfCollegeFilter(this.collegeId, this.courseid, this.CourseLeve, this.fees, this.acceptedexam, this.seachform.value.searchCourse).subscribe(res => {
      // console.log(res);
      this.popupClose();
      this.courses_listArr = res.courses_list;

    })
  }

  getCourses(item) {
    console.log(item);
    this.courseid = item;
  }

  getCourseLevellist(item) {
    this.CourseLeve = item.id;
  }

  getFees(item) {
    this.fees = item.total_fees;

  }

  gethighFees(item) {
    // console.log(item)
    this.fees = '<' + item;
  }

  getlowFees(item) {
    // console.log(item)
    this.fees = '>' + item;
  }


  getExamAcceptedlist(item) {
    this.acceptedexam = item.id
  }

  openCourseFilter() {
    this.dialog.open(this.CourseFilter);
  }

  popupClose() {
    this.dialog.closeAll();
  }

  getCollegeDetailsByID():void {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      this.cityid = res.college_detail[0].cityid;
      // console.log(this.cityid)
      this.getOtherCollegesOfferingSameCourseInSameCity();
      // this.Estd = res.college_detail[0].estd;
      // this.location = res.college_detail[0].city;
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      // this.logo = res.college_detail[0].logo;
      // this.CoursesArr = res.college_detail[0].Courses;
      // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
      // this.table_of_contentArr = res.table_of_content;
      // // this.whats_new=res.college_detail[0].what_new;
      // this.whats_new = this.safeHtml((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;

    });
  }

  //Get College programs by college id 
  getCollegeProgrammesByID() {
    this.CompareclgService.getCollegeProgrammesByID(this.collegeId).subscribe(res => {
      this.CoursesArr = res.popular_programmes;
      this.popularProgramsFaqsArr = res.Commonaly_Asked_Questions;
    })
  }

  getcourses(subcategory){
    this.CompareclgService.getCoursesBySubcategory(this.collegeId, subcategory).subscribe(res => {
      // console.log(res);
      // this.CoursesArr = res.popular_programmes;
      this.courses_listArr = res.courses_list;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    })
  }

  //get courses by subcategory form college info page 
  getCollegeProgrammesBySubCatID() {
    this.CompareclgService.getCoursesBySubcategory(this.collegeId, this.subcatId).subscribe(res => {
      // console.log(res);
      // this.CoursesArr = res.popular_programmes;
      this.courses_listArr = res.courses_list;
    })
  }

  //For courses display
  getCoursesOfCollege() {
    this.CompareclgService.getCoursesOfCollege(this.collegeId).subscribe(res => {
      this.courses_listArr = res.courses_list;
    })
  }

  //For FAQs of courses and Fees
  getCoursesAndFeesOfClg() {
    this.CompareclgService.getCoursesAndFeesOfClg(this.collegeId).subscribe(res => {
      // this.coursesAndFeesArr = res.courselist;
      this.CoursesFeesFaqsArr = res.Commonaly_Asked_Questions;
    })
  }

  getCollegeDetails(collegeid){
    console.log(collegeid)
    this.tab = 0;
    this.router.navigate(['/collegeDetails', collegeid]);
    localStorage.setItem('selectedTabIndex', this.tab.toString());
  }


  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }

  getOtherCollegesOfferingSameCourseInSameCity() {
    // console.log(this.cityid)
    this.CompareclgService.getOtherCollegesOfferingSameCourseInSameCity(this.cityid,this.collegeId).subscribe(res => {
      // console.log(res);
      this.SameCourseInSameCityArr = res.courses_list;
    })
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }


  openImageDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  close() {
    this.dialog.closeAll();
  }


  //APIs for Filter Dropdown
  getSubCategoryList() {
    this.FilterLoadercourse = true;
    this.CompareclgService.getSubCategoryList(this.collegeId).subscribe(res => {
      this.SubCategoryArr = res.SubCategory;
      this.FilterLoadercourse = false;
    })
  }

  getCourseLevel() {
    this.FilterLoadercourselevel = true;
    this.CompareclgService.getCourseLevel(this.collegeId).subscribe(res => {
      this.CourseLevelArr = res.SubCategory;
      this.FilterLoadercourselevel = false;
    })
  }

  getExamAccepted() {
    this.CompareclgService.getExamAccepted(this.collegeId).subscribe(res => {
      // console.log(res);
      this.ExamAcceptedArr = res.SubCategory;
    })
  }

  getFeesDataOfCollege() {
    this.FilterLoaderfees = true;
    this.CompareclgService.getFeesDataOfCollege(this.collegeId).subscribe(res => {
      // console.log(res);
      this.FilterLoaderfees = false;
      this.fees_listArr = res.fees_list.all_fees;
      this.highest_fee = res.fees_list.highest_fee;
      this.lowest_fee = res.fees_list.lowest_fee;
      //  console.log(this.highest_fee);
    })
  }

  AddCourseIntoTabe(courseId:string,courseName) {
    console.log(courseId)
    // this.router.navigate(['/collegeDetails',this.collegeId,'courseinfo',courseId])
    localStorage.setItem('CourseID', courseId);
    localStorage.setItem('courseName', courseName);
    this.courseClicked.emit(courseId);
    // this.CourseIntoTab=true;
  }

  downloadBrochure() {
    // alert(78)
    this.CompareclgService.downloadBrochure(this.collegeId, '1').subscribe(res => {
      console.log(res);
    
      Swal.fire(res.response_message);
    })
  }

  getCompareCollege(){
    this.router.navigate(['/collegeDetails/' + this.collegeId + '/compare/comparecollege/compareDetails']);
  }

  getArticleDetails(BlogId) {
    this.router.navigate(['/articledetails', BlogId])
  }
}
