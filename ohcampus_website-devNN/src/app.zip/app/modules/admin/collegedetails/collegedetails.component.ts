import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTabChangeEvent, MatTabGroup } from '@angular/material/tabs';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'app/core/auth/auth.service';
import { LoginpopupService } from 'app/shared/loginpopup.service';
import { Location } from '@angular/common';
// import {swal } from 'sweetalert2';
// import { GoogleMap } from '@angular/google-maps';
import { BehaviorSubject, Observable, forkJoin } from 'rxjs';
import * as xlsx from 'xlsx';
import Swal from 'sweetalert2';

declare var google: any;

interface marker {
  lat: number;
  lng: number;
  label?: string;
  draggable: boolean;
}
const VIDEO_URL =
  'https://youtu.be/P7dtJ2UlHa0?si=xWerKkLe4qBlEmuO';


const navigationExtras: NavigationExtras = {
  replaceUrl: true,
};
@Component({
  selector: 'app-collegedetails',
  templateUrl: './collegedetails.component.html',
  styleUrls: ['./collegedetails.component.scss']
})

export class CollegedetailsComponent implements OnInit {
  @ViewChild('tabGroup') tabGroup!: MatTabGroup;
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  @ViewChild('callAPIDialogapply') callAPIDialogapply: TemplateRef<any>;
  @ViewChild('callAPIDialogpredictAdm') callAPIDialogpredictAdm: TemplateRef<any>;
  @ViewChild('ImportantDates', { static: false }) ImportantDates: ElementRef;
  PlacementForm: FormGroup;
  applicationForm: FormGroup;
  predictAdmForm: FormGroup;

  //DECLARE Arrays
  CoursesArr: any = []; CollegeHighlightArr: any = []; table_of_contentArr: any = []; PlacementCategoryArr: any = []; placementDataArr: any = []; campusImagesArr: any = [];
  NotificationArr: any = []; rankArr: any = []; coursesAndFeesArr: any = []; placement_faqsArr: any = []; displayedQuestions: any[] = []; phonearr: any = [];
  latest_blogsArr: any = []; CoursesFeesFaqsArr: any = []; CoursesForSameGroupArr: any = []; rankFaqsArr: any = []; popularProgramsFaqsArr: any = [];
  contactDetailsArr: any = []; collegeByLocationArr: any = []; collegeFAQsArr: any = []; AdmissionProcessArr: any = []; AdmissionProcessFAQArr: any = []; popular_blogsArr: any = [];
  ScholorshipFAQsArr: any = []; scholarship_dataArr: any = []; CollegeHighlightFaqArr: any = []; CollegeHighlight: any = [];
  CourseCategoryArr: any = []; CoursesByCatArr: any = []; examListArr: any = [];

  //DECLARE VARIABLES
  videoWidget: any; collegeId: any; collegename: any; Estd: any; location: any; Collage_category: any; image: any; logo: any;
  whats_new: SafeHtml; ALLFAQS: Boolean = false; TabselectedIndex: number = 0;
  highlightExpanded: boolean = false;
  CourseIntoTab: boolean = false;

  currentYear = (new Date()).getFullYear();
  YearValue: any;
  visibleItemsCount: number = 10; // Number of items to display initially
  showMore: boolean = true; cityid: any;

  initiallyDisplayedCount = 5; initialDisplayCount = 4; initialDisplayCountRanking = 4; initialDisplayFAQ = 4; initialDisplayPopularPrograms = 4; initialDisplayAdm = 4;
  initialDisplayCoursesFees = 4; selectedTabIndex = 4;
  // google maps zoom level
  zoom: number = 8;

  // initial center position for the map
  lat: number = 13.014423532655991; lng: number = 77.5677750496948;

  collegename1: string; email: any; website: any; sub_category: any; description: any; TabId: number; TabLabel: string; scholarship_data: any; showLoader: boolean = true;
  reviews: any[] = []; isLoading = true;
  totalRateCount: any;
  totalReview: any;
  package_type: any;
  application_link: any;

  constructor(
    private loc: Location,
    private _formBuilder: FormBuilder,
    public dialog: MatDialog,
    private route: Router,
    private _activatedRoute: ActivatedRoute,
    public CompareclgService: CompareclgService,
    private sanitizer: DomSanitizer,
    public authService: AuthService,
    public LoginpopupService: LoginpopupService,
    private el: ElementRef) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    console.log(routeParams);

    const storedTabIndex = localStorage.getItem('selectedTabIndex');
    if (storedTabIndex) {
      this.TabselectedIndex = +storedTabIndex;
    }

    this.PlacementForm = this._formBuilder.group({
      course_category: ['',],
      year: [''],
    })

    this.applicationForm = this._formBuilder.group({
      name: ['', Validators.required],
      mobileno: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      course_category: ['', Validators.required],
      college: ['', Validators.required],
      course: ['', Validators.required],
      exam: ['', Validators.required],
      expected_rank: ['', Validators.required],
      expected_score: ['', Validators.required]
    })


    this.predictAdmForm = this._formBuilder.group({
      name: ['', Validators.required],
      mobileno: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      course_category: ['', Validators.required],
      college: ['', Validators.required],
      course: ['', Validators.required],
      exam: ['', Validators.required],
      expected_rank: ['', Validators.required],
      expected_score: ['', Validators.required]
    })



    this.PlacementForm.get('course_category').setValue('2');
    this.PlacementForm.get('year').setValue('2024');

    this.collegeId = routeParams.id;
    // this.switchToDetailsTab()
    this.getCollegeDetailsByID();
    this.getCollegeTotalRate();
    this.getCollegeHighlightByID();
    this.getPlacementCategory();
    this.getPlacementDataOfClg1();
    this.getExamNotificationForClg();
    this.getRanktDataOfClg();
    this.getCoursesAndFeesOfClg();
    this.getCollegeProgrammesByID();
    this.coursesOfferedInSameGroup();
    this.getCollegeContactDetails();
    this.getcollegeByLocation();
    this.getFAQsOfClg();
    this.getCollegeAdmissionProcess();
    this.getLatestBlogs();
    this.getScholarShipOfClg();
    this.getCourseCategory();
    this.getExamList();
    const placeId = this.collegeId; // Replace with the actual Google Place ID
    // this.CompareclgService.getPlaceReviews(placeId).subscribe((data: any) => {
    //   console.log(data)
    //   // this.reviews = data.result.reviews;
    //   // console.log(this.reviews);
    // });

  }
  // getAllData(): Observable<any> {
  //   return forkJoin([
  //     this.getCollegeDetailsByID(),
  //     this.getCollegeHighlightByID(),
  //     this.getPlacementCategory(),
  //     this.getPlacementDataOfClg1(),
  //     this.getExamNotificationForClg(),
  //     this.getRanktDataOfClg(),
  //     this.getCoursesAndFeesOfClg(),
  //     this.getCollegeProgrammesByID(),
  //     this.coursesOfferedInSameGroup(),
  //     this.getCollegeContactDetails(),
  //     this.getcollegeByLocation(),
  //     this.getFAQsOfClg(),
  //     this.getCollegeAdmissionProcess(),
  //     this.getLatestBlogs(),
  //     this.getScholarShipOfClg(),
  //   ]);
  // }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.showLoader = false;
    }, 2000);
  }

  panelOpenState = false;

  readonly VIDEO_URL = VIDEO_URL;
  onCourseClicked(courseId: string): void {
    this.CourseIntoTab = true;
    this.TabselectedIndex = 11;
    // this.route.navigate(['/collegeDetails/' + this.collegeId, ''])
  }

  statusBarClick($event: MouseEvent) {
    const el = $event.target as HTMLElement;
    const clickX = $event.offsetX;
    const totalWidth = el.offsetWidth;

    this.videoWidget.duration$.pipe().subscribe(duration => {
      const percentComplete = clickX / totalWidth;
      this.videoWidget.seek(duration * percentComplete);
    });
  }

  mapClicked($event: MouseEvent) {
    // this.markers.push({
    //   lat: $event.coords.lat,
    //   lng: $event.coords.lng,
    //   draggable: true
    // });
  }

  // onQuestionClick(index: number) {
  //   // Check if the clicked question is the last one
  //   if (index === this.displayedQuestions.length - 1) {
  //     // Add the next question below the clicked one
  //     const nextQuestionIndex = index + 1;
  //     const nextQuestion = this.placement_faqsArr[nextQuestionIndex];
  //     if (nextQuestion) {
  //       this.displayedQuestions.splice(nextQuestionIndex, 0, nextQuestion);
  //     }
  //   }
  // }

  showNextQuestionPlacement() {
    this.initialDisplayCount += 1; // Increment the count to show the next question
  }

  showNextQuestionRanking() {
    this.initialDisplayCountRanking += 1;
  }

  showNextQuestionFAQ() {
    this.initialDisplayFAQ += 1;
  }

  showNextQuestionPopularPrograms() {
    this.initialDisplayPopularPrograms += 1;
  }

  showNextQuestionAdm() {
    this.initialDisplayAdm += 1;
  }

  showNextQuestionCoursesFees() {
    this.initialDisplayCoursesFees += 1;
  }

  Year = [
    { value: 'opt-1', viewValue: '2024' },
    { value: 'opt-2', viewValue: '2023' },
    { value: 'opt-3', viewValue: '2022' },
    { value: 'opt-4', viewValue: '2021' },
    { value: 'opt-5', viewValue: '2020' },
    // { value: 'opt-2', viewValue: '2023' },
  ];

  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      this.collegename1 = this.collegename
      this.Estd = res.college_detail[0].estd;
      this.location = res.college_detail[0].city;
      this.Collage_category = res.college_detail[0].Collage_category;
      this.image = res.college_detail[0].image;
      this.logo = res.college_detail[0].logo;
      this.cityid = res.college_detail[0].cityid;
      this.description = res.college_detail[0].description
      this.package_type = res.college_detail[0].package_type
      this.application_link = res.application_link;
      // console.log(res.college_detail[0].CollegeHighlight[0]);
      // this.CollegeHighlight = this.safeHtml(res.college_detail[0].CollegeHighlight[0].text);
      this.table_of_contentArr = res.table_of_content;
      // this.whats_new=res.college_detail[0].what_new;
      // this.whats_new = this.safeHtml((res.college_detail[0].what_new));
      this.whats_new = ((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;
    });
  }
  markers: marker[] = [
    {
      lat: 51.673858,
      lng: 7.815982,
      label: 'ABC',
      draggable: true
    },
    // {
    //   lat: 51.373858,
    //   lng: 7.215982,
    //   label: 'B',
    //   draggable: false
    // },
    // {
    //   lat: 51.723858,
    //   lng: 7.895982,
    //   label: 'C',
    //   draggable: true
    // }
  ]
  isHovered: boolean = false;

  onHover(value: boolean): void {
    this.isHovered = value;
  }

  getUniqueEntranceExams(item: any): string {
    if (item && item.entrance_exam_names) {
      const uniqueExams = Array.from(new Set(item.entrance_exam_names.split(',')));
      return uniqueExams.join(', ');
    } else {
      return '';
    }
  }

  openImageDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  close() {
    this.dialog.closeAll();
  }

  getPlacementCategory() {
    this.CompareclgService.getPlacementCategory().subscribe(res => {
      // console.log(res);
      this.PlacementCategoryArr = res.response_data;
    })
  }

  getCollegeHighlightByID() {
    this.CompareclgService.getCollegeHighlightByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.CollegeHighlightArr = res.CollegeHighlight;
      this.CollegeHighlightFaqArr = res.Commonaly_Asked_Questions;
    })
  }

  isWordPresent(word: string): boolean {
    // Check if the word is present in any of the title of the table of content
    return this.table_of_contentArr.some(item => item.title.toLowerCase().includes(word.toLowerCase()));
  }

  //get all course tab on view all courses
  getAllCousesTab() {
    this.tabGroup.selectedIndex = 1;
  }

  //get admission course tab on view all admission
  getAdmissionTab() {
    this.tabGroup.selectedIndex = 3;
  }

  //get cutoff tab on view all cutoffs
  getCutoffsTab() {
    this.tabGroup.selectedIndex = 5;
  }

  //getplacement tab on view all placements
  getPlacementTab() {
    this.tabGroup.selectedIndex = 4;
  }

  safeHtml(value) {
    return this.sanitizer.bypassSecurityTrustHtml(value);
  }

  getContent(index: number) {
    this.highlightExpanded = !this.highlightExpanded;
  }

  scrollTo(sectionName: string, id): void {
    // console.log(section);
    const element = this.el.nativeElement.querySelector(`[name="${sectionName}"]`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }


  //Export to Excel
  exportToExcel() {
    const ws: xlsx.WorkSheet = xlsx.utils.table_to_sheet(this.ImportantDates.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'ImportantDates.xlsx');
  }

  getPlacementDataOfClg() {
    this.CompareclgService.getPlacementDataOfClg(this.PlacementForm.value.year, this.PlacementForm.value.course_category, this.collegeId,).subscribe(res => {
      this.YearValue = this.PlacementForm.value.year;
      this.placementDataArr = res.placementlist;
      this.placement_faqsArr = res.Commonaly_Asked_Questions;
      // this.displayedQuestions = this.placement_faqsArr.slice(0, this.initiallyDisplayedCount);
      console.log(this.displayedQuestions)
      if (res.response_code == 400) {
        this.placement_faqsArr = [];
      }
    })
  }
  getPlacementDataOfClg1() {
    this.CompareclgService.getPlacementDataOfClg("2024", "2", this.collegeId,).subscribe(res => {
      this.YearValue = this.PlacementForm.value.year;
      this.placementDataArr = res.placementlist;
      this.placement_faqsArr = res.Commonaly_Asked_Questions;
      // this.displayedQuestions = this.placement_faqsArr.slice(0, this.initiallyDisplayedCount);
      if (res.response_code == 400) {
        this.placement_faqsArr = [];
      }
    })
  }

  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }

  getRanktDataOfClg() {
    this.CompareclgService.getRanktDataOfClg(this.collegeId).subscribe(res => {
      // console.log(res);
      this.rankArr = res.rankList;
      this.rankFaqsArr = res.Commonaly_Asked_Questions;
    })
  }

  getCoursesAndFeesOfClg() {
    this.CompareclgService.getCoursesAndFeesOfClg(this.collegeId).subscribe(res => {
      // console.log(res);
      this.coursesAndFeesArr = res.courselist;
      this.CoursesFeesFaqsArr = res.Commonaly_Asked_Questions;
    })
  }

  getScholarShipOfClg() {
    this.CompareclgService.getScholarShipOfClg(this.collegeId).subscribe(res => {
      // console.log(res);
      this.scholarship_dataArr = res.scholarship_data;
      this.scholarship_data = res.scholarship_data[0].scholarship;
      this.ScholorshipFAQsArr = res.Commonaly_Asked_Questions;
    })
  }



  toggleVisibility(): void {
    this.showMore = !this.showMore;
    if (this.showMore) {
      this.visibleItemsCount = 10; // Display first 10 items
    } else {
      this.visibleItemsCount = this.coursesAndFeesArr.length; // Display all items
    }
  }

  getCollegeProgrammesByID() {
    this.CompareclgService.getCollegeProgrammesByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.CoursesArr = res.popular_programmes;
      this.popularProgramsFaqsArr = res.Commonaly_Asked_Questions;
    })
  }

  coursesOfferedInSameGroup() {
    this.CompareclgService.coursesOfferedInSameGroup(this.collegeId).subscribe(res => {
      // console.log(res);
      this.CoursesForSameGroupArr = res.coursesOfferedInSameGroup;
    })
  }

  getCollegeContactDetails() {
    this.CompareclgService.getCollegeContactDetails(this.collegeId).subscribe(res => {
      // console.log(res);
      // this.contactDetailsArr = res.ContactDetails;
      this.contactDetailsArr = res.ContactDetails[0].phone;
      // console.log(this.contactDetailsArr.split(','));
      this.phonearr = this.contactDetailsArr.split(',');
      // console.log(this.phonearr)
      this.email = res.ContactDetails[0].email;
      this.website = res.ContactDetails[0].web;
    })
  }

  getcollegeByLocation() {
    this.CompareclgService.getcollegeByLocation(this.cityid, this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegeByLocationArr = res.collegeByLocation;
    })
  }

  getFAQsOfClg() {
    this.CompareclgService.getFAQsOfClg(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegeFAQsArr = res.FAQs;
      if (res.response_message == 'Failed') {
        this.ALLFAQS = true;
      }
    })
  }

  getCollegeAdmissionProcess() {
    this.CompareclgService.getCollegeAdmissionProcess(this.collegeId).subscribe(res => {
      this.AdmissionProcessArr = res.AdmissionProcess;
      this.AdmissionProcessFAQArr = res.Commonaly_Asked_Questions;

    })
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  getCoursesBySubcategory(sub_category) {
    // console.log(sub_category);
    this.sub_category = sub_category;
    this.onTabChange(1);
    this.route.navigate(['/collegeDetails/' + this.collegeId, this.TabLabel, this.sub_category]);
  }

  getCollegeTotalRate() {
    this.CompareclgService.getCollegeTotalRate(this.collegeId).subscribe(res => {
      // console.log(res);
      this.totalRateCount = res.data.totalRateCount;
      this.totalReview = res.data.totalReview;
    })
  }

  onTabChange(index: number) {

    this.TabselectedIndex = index;
    localStorage.setItem('selectedTabIndex', index.toString());
    // console.log(this.TabselectedIndex);
    const selectedTabLabel = this.getTabLabelByIndex(index);
    this.TabLabel = selectedTabLabel;
    this.route.navigate(['/collegeDetails/' + this.collegeId, selectedTabLabel])
    if (this.CourseIntoTab && selectedTabLabel == 'CoursesFees') {
      this.CourseIntoTab = false;
    }
    // if (this.CourseIntoTab && selectedTabLabel == 'Reviews') {
    //   this.CourseIntoTab = false;
    //   // console.log(this.TabselectedIndex)
    //   this.TabselectedIndex = this.TabselectedIndex - 1;
    //   this.TabselectedIndex = index;
    //   localStorage.setItem('selectedTabIndex', index.toString());
    // }
    console.log('Selected tab label:', selectedTabLabel);
    return;
    // const selectedTabLabel = this.getTabLabelByIndex(event);
    // this.TabLabel = selectedTabLabel
    // localStorage.setItem('selectedTab', selectedTabLabel);
    // this.route.navigate(['/collegeDetails/' + this.collegeId, selectedTabLabel])
    // console.log('Selected tab label:', selectedTabLabel);
  }

  private getTabLabelByIndex(index: number): string {
    this.TabId = index;
    // console.log(index);
    const tabs = ['', 'CoursesFees', 'Reviews', 'Admissions', 'Placements', 'CutOffs', 'HostelCampus', 'Compare', 'QA', 'Scholarship', 'News'];

    if (this.CourseIntoTab == true) {
      const tabs = ['', 'CoursesFees', '', 'Reviews', 'Admissions', 'Placements', 'CutOffs', 'HostelCampus', 'Compare', 'QA', 'Scholarship', 'News'];
      return tabs[index];
    }
    return tabs[index];
  }


  apply() {
    if (!this.authService.isLoggedIn()) {
        this.LoginpopupService.openLoginPopup();
    }
    else
    {
    if (this.application_link != null) {
      window.open(this.application_link)
    }
    else {
      const dialogRef = this.dialog.open(this.callAPIDialogapply);
      this.applicationForm.get('college').setValue(this.collegename);
      dialogRef.afterClosed().subscribe((result) => { });

    }
}
  }

  //--------------------only Numbers are allowed---------------------//
  numberOnly(event): boolean {
    // console.log(event.target.value)
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  predictAdm() {
    if (this.application_link != null) {
      // window.open(this.application_link)
    }
    else {
        if (!this.authService.isLoggedIn()) {
            this.LoginpopupService.openLoginPopup();
        }
        else
        {
      const dialogRef = this.dialog.open(this.callAPIDialogpredictAdm);
      this.predictAdmForm.get('college').setValue(this.collegename);
      dialogRef.afterClosed().subscribe((result) => { });
        }
    }
  }

  downloadBrochure() {
    if (!this.authService.isLoggedIn()) {
      this.LoginpopupService.openLoginPopup();
  }
  else
  {    this.CompareclgService.downloadBrochure(this.collegeId, '1').subscribe((res) => {
      console.log(res);
      Swal.fire(res.response_message);
    })
  }
}


  getCourseCategory() {
    this.CompareclgService.getCourseCategory().subscribe(res => {
      // console.log(res);
      this.CourseCategoryArr = res.data;
    })
  }

  // getCourseByCategory() {
  //   this.CompareclgService.getCourseByCategory(this.applicationForm.value.course_category).subscribe(res => {
  //     console.log(res);
  //     this.CoursesByCatArr = res.data;
  //   })
  // }
  getCourseByCategoryClg() {
    this.CompareclgService.getCourseByCategoryClg(this.applicationForm.value.course_category, this.collegeId).subscribe(res => {
      // console.log(res);
      this.CoursesByCatArr = res.data

    })
  }

  getCourseByCategoryClg2() {
    this.CompareclgService.getCourseByCategoryClg(this.predictAdmForm.value.course_category, this.collegeId).subscribe(res => {
      // console.log(res);
      this.CoursesByCatArr = res.data

    })
  }

  getExamList() {
    // this.ExamLoader = true;
    this.CompareclgService.getExamList('').subscribe(res => {
      // console.log(res);
      // this.ExamLoader = false;
      this.examListArr = res.response_data;
    })
  }


  savCourseApplication() {
    if (!this.authService.isLoggedIn()) {
      this.LoginpopupService.openLoginPopup();
  }
  else
  {
    if (this.applicationForm.invalid) {
      this.applicationForm.markAllAsTouched();
      return
    }
    if (this.applicationForm.valid) {
      this.CompareclgService.savCourseApplication(
        this.applicationForm.controls.name.value,
        this.applicationForm.controls.email.value,
        this.applicationForm.controls.mobileno.value,
        this.applicationForm.controls.course_category.value,
        this.collegeId,
        this.applicationForm.controls.course.value,
        this.applicationForm.controls.exam.value,
        this.applicationForm.controls.expected_rank.value,
        this.applicationForm.controls.expected_score.value,
      ).subscribe(res => {
        console.log(res);
        this.close();
      })
    }
  }
  }

  savPredictAdmission() {
    if (!this.authService.isLoggedIn()) {
        this.LoginpopupService.openLoginPopup();
    }else
    {
    if (this.predictAdmForm.invalid) {
      this.predictAdmForm.markAllAsTouched();
      return
    }
    if (this.predictAdmForm.valid) {
      this.CompareclgService.savPredictAdmission(
        this.predictAdmForm.controls.name.value,
        this.predictAdmForm.controls.email.value,
        this.predictAdmForm.controls.mobileno.value,
        this.predictAdmForm.controls.course_category.value,
        this.collegeId,
        this.predictAdmForm.controls.course.value,
        this.predictAdmForm.controls.exam.value,
        this.predictAdmForm.controls.expected_rank.value,
        this.predictAdmForm.controls.expected_score.value,
      ).subscribe(res => {
        console.log(res);
        this.close();
      })
    }
  }
}

  getArticleDetails(BlogId) {
    this.route.navigate(['/articledetails', BlogId])
  }

  getCollegeDetails(collegeid) {
    // console.log(collegeid)
    // this.collegeId = collegeid;
    // this.route.navigate(['/collegeDetails', this.collegeId],navigationExtras);
  }

  AdmissionProcessImportantDatesPDF(sub_category) {
    if (!this.authService.isLoggedIn()) {
        this.LoginpopupService.openLoginPopup();
    }
    else
    {
    this.CompareclgService.AdmissionProcessImportantDatesPDF(this.collegeId, sub_category).subscribe(res => {
      console.log(res);
      let viewPDF = res;
      window.open(viewPDF.PDF, "_blank")
    })
  }
}
}
