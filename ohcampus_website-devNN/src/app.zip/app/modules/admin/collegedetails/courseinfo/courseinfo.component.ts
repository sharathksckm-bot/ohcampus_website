
import { Component, OnInit, ViewChild, TemplateRef, ElementRef, EventEmitter, Output, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-courseinfo',
  templateUrl: './courseinfo.component.html',
  styleUrls: ['./courseinfo.component.scss']
})
export class CourseinfoComponent implements OnInit {

  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  @ViewChild('popupFilter') popupFilter: TemplateRef<any>;
  @ViewChild('callAPIDialogapply') callAPIDialogapply: TemplateRef<any>;

  applicationForm: FormGroup;
  studentForum: FormGroup;
  application_link: any;
  collegeId: any;
  collegename: any;
  CourseCategoryArr: any = [];
  CoursesByCatArr: any = [];
  examListArr: any = [];
  campusImagesArr: any = [];
  NotificationArr: any = [];
  latest_blogsArr: any = [];
  popular_blogsArr: any = [];
  coursefeesArr: any = [];
  courseinfoArr: any = [];
  coursefeesArray: any = [];
  commanlyaskedqaeArr: any = [];
  EntranceExamsArr: any = [];
  popularClgByLocArr: any = [];
  colleges_Offereing_SameCourseArr: any = [];
  CollegesAccordingCategoryArr: any = [];
  QueAnsAboutCoursesArray: any = [];
  image: any;
  courseId: string;
  courseName: string;
  cityid: any;
  location: any;
  course_category: any;
  category: any;
  categoryId: any;
  tab: number;
  // @Input() courseId: any;

  constructor(
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    public CompareclgService: CompareclgService,
    public dialog: MatDialog,
    // public LoginpopupService: LoginpopupService,
    private sanitizer: DomSanitizer,
    private _formBuilder: FormBuilder,
    private el: ElementRef) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    console.log(routeParams);
    this.collegeId = routeParams.id;
    // console.log(this.courseId)
    this.courseId = localStorage.getItem('CourseID');
    this.courseName = localStorage.getItem('courseName');
    console.log(this.courseId)
    this.applicationForm = this._formBuilder.group({
      name: ['', Validators.required],
      mobileno: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      course_category: ['', Validators.required],
      college: ['', Validators.required],
      course: ['', Validators.required],
      exam: ['', Validators.required],
      expected_rank: ['', Validators.required],
      expected_score: ['', Validators.required]
    })

    this.studentForum = this._formBuilder.group({
      studentque: ['']
    })

    this.getCollegeDetailsByID();
    this.getExamNotificationForClg();
    this.getCourseCategory();
    this.getExamList();
    this.getLatestBlogs();
    this.getCoursesFeeStructure();
    this.getCoursesInfo();
    this.getCoursesAdmissionProcess();
    this.getQueAnsAboutCourses();
    this.getEntranceExamsForCourse();
    // this.getPopularClgByLocation();
  }

  openFilter() {
    this.dialog.open(this.popupFilter);
  }
  popupClose() {
    this.dialog.closeAll();
  }

  openImageDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  close() {
    this.dialog.closeAll();
  }


  // close() {
  //   this.dialog.closeAll();
  // }

  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      // this.collegename1 = this.collegename
      // this.Estd = res.college_detail[0].estd;
      this.location = res.college_detail[0].city;
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      // this.logo = res.college_detail[0].logo;
      this.cityid = res.college_detail[0].cityid;
      this.collegesOffereingSameCourseAtSameCity();
      this.getPopularClgByLocation();
      this.category = res.college_detail[0].category;
      this.categoryId = res.college_detail[0].categoryid;
      this.getCollegesAccordingCategory();
      // getPopularClgByLocation
      // this.description = res.college_detail[0].description
      // this.package_type = res.college_detail[0].package_type
      this.application_link = res.application_link;
      // console.log(res.college_detail[0].CollegeHighlight[0]);
      // this.CollegeHighlight = this.safeHtml(res.college_detail[0].CollegeHighlight[0].text);
      // this.table_of_contentArr = res.table_of_content;
      // // this.whats_new=res.college_detail[0].what_new;
      // // this.whats_new = this.safeHtml((res.college_detail[0].what_new));
      // this.whats_new = ((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;
    });
  }

  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }

  //--------------------only Numbers are allowed---------------------//
  numberOnly(event): boolean {
    // console.log(event.target.value)
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }


  apply() {
    if (this.application_link != null) {
      window.open(this.application_link)
    }
    else {
      const dialogRef = this.dialog.open(this.callAPIDialogapply);
      console.log(this.collegename);
      this.applicationForm.get('college').setValue(this.collegename);
      dialogRef.afterClosed().subscribe((result) => { });

    }
  }

  getCourseCategory() {
    this.CompareclgService.getCourseCategory().subscribe(res => {
      // console.log(res);
      this.CourseCategoryArr = res.data;
    })
  }

  getCourseByCategoryClg() {
    this.CompareclgService.getCourseByCategoryClg(this.applicationForm.value.course_category, this.collegeId).subscribe(res => {
      // console.log(res);
      this.CoursesByCatArr = res.data

    })
  }

  getExamList() {
    // this.ExamLoader = true;
    this.CompareclgService.getExamList('').subscribe(res => {
      // console.log(res);
      // this.ExamLoader = false;
      this.examListArr = res.response_data;
    })
  }

  savCourseApplication() {
    if (this.applicationForm.invalid) {
      this.applicationForm.markAllAsTouched();
      return
    }
    if (this.applicationForm.valid) {
      this.CompareclgService.savCourseApplication(
        this.applicationForm.controls.name.value,
        this.applicationForm.controls.email.value,
        this.applicationForm.controls.mobileno.value,
        this.applicationForm.controls.course_category.value,
        this.collegeId,
        this.applicationForm.controls.course.value,
        this.applicationForm.controls.exam.value,
        this.applicationForm.controls.expected_rank.value,
        this.applicationForm.controls.expected_score.value,
      ).subscribe(res => {
        console.log(res);
        this.close();
      })
    }
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  getCoursesFeeStructure() {
    console.log(this.courseId)
    this.CompareclgService.getCoursesFeeStructure(this.courseId, this.collegeId).subscribe(res => {
      console.log(res);
      this.coursefeesArr = res.coursefees
    })
  }

  getCoursesInfo() {
    this.CompareclgService.getCoursesInfo(this.courseId, this.collegeId).subscribe(res => {
      console.log(res);
      this.courseinfoArr = res.courseinfo;
      this.course_category=res.courseinfo[0].levelid;
    })
  }

  getCoursesAdmissionProcess() {
    this.CompareclgService.getCoursesAdmissionProcess(this.courseId, this.collegeId).subscribe(res => {
      console.log(res);
      this.coursefeesArray = res.coursefees;
      this.commanlyaskedqaeArr = res.Commonaly_Asked_Questions;
    })
  }

  getQueAnsAboutCourses() {
    this.CompareclgService.getQueAnsAboutCourses(this.collegeId, this.courseId,).subscribe(res => {
      console.log(res);
      this.QueAnsAboutCoursesArray=res;
      if(res.response_code==400){
        this.QueAnsAboutCoursesArray=[];
      }
      // this.commanlyaskedqaeArr=res.Commonaly_Asked_Questions;
    })
  }

  getEntranceExamsForCourse() {
    this.CompareclgService.getEntranceExamsForCourse(this.courseId, this.collegeId,).subscribe(res => {
      console.log(res);
      this.EntranceExamsArr = res.EntranceExams;
      // this.commanlyaskedqaeArr=res.Commonaly_Asked_Questions;
    })
  }

  getExamDetails(ExamId) {
    this.router.navigate(['/examsdetails', ExamId]);
  }

  collegesOffereingSameCourseAtSameCity() {
    this.CompareclgService.collegesOffereingSameCourseAtSameCity(this.courseId, this.cityid,this.collegeId).subscribe(res => {
      // console.log(res)
      this.colleges_Offereing_SameCourseArr = res.colleges_Offereing_SameCourse;
    })
  }

  postQuestion() {
    this.CompareclgService.postQuestion(this.collegeId, this.course_category, this.courseId, '22', this.studentForum.value.studentque).subscribe(res => {
      // console.log(res);
      // this.QAform.reset();
    })
  }

  getPopularClgByLocation() {
    this.CompareclgService.getPopularClgByLocation(this.cityid).subscribe(res => {
      // console.log(res);
      this.popularClgByLocArr = res.CollegeListForCompare;
    })
  }

  getCollegesAccordingCategory() {
    this.CompareclgService.getCollegesAccordingCategory(this.collegeId, this.categoryId).subscribe(res => {
      // console.log(res);
      this.CollegesAccordingCategoryArr = res.bestSuitedColleges;
    })
  }

  getArticleDetails(ArticleId){
    this.router.navigate(['/articledetails', ArticleId])
  }

  getCollegeDetails(collegeid){
    this.tab = 0;
    this.router.navigate(['/collegeDetails', collegeid]);
    localStorage.setItem('selectedTabIndex', this.tab.toString());
  }
}
