import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
@Component({
  selector: 'app-faqs',
  templateUrl: './faqs.component.html',
  styleUrls: ['./faqs.component.scss']
})
export class FaqsComponent implements OnInit {
  collegeId: any;
  // FAQsOfClgArr: any=[];

  constructor( private _activatedRoute: ActivatedRoute,public CompareclgService: CompareclgService) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    // this.getFAQsOfClg();
  }
  // getFAQsOfClg() {
  //   this.CompareclgService.getFAQsOfClg(this.collegeId).subscribe(res => {
  //     // console.log(res);
  //     this.FAQsOfClgArr=res.FAQs
  //   })
  // }
}
