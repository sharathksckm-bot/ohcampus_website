import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';

@Component({
  selector: 'app-scolarship',
  templateUrl: './scolarship.component.html',
  styleUrls: ['./scolarship.component.scss']
})
export class ScolarshipComponent implements OnInit {
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;

  studentForum: FormGroup;
  collegeId: any;
  NotificationArr: any = [];
  campusImagesArr: any = [];
  latest_blogsArr: any = [];
  popular_blogsArr: any = [];
  scholarship_dataArr: any = [];
  QueAnsAboutScholarshipArr: any = [];
  popularClgByLocArr: any = [];
  CollegesAccordingCategoryArr: any = [];
  infraReviewsArr: any = [];
  // latest_blogsArr:any=[];
  collegename: any;
  image: any;
  course_category: any;
  course: any;
  scholarship_data: any;
  totalInfrastructureRate: any;
  two2threeRate: any;
  one2twoRate: any;
  three2fourRate: any;
  four2fiveRate: any;
  cityid: any;
  category: any;
  categoryId: any;

  constructor(
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    public CompareclgService: CompareclgService,
    private sanitizer: DomSanitizer,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    this.studentForum = this._formBuilder.group({
      studentque: ['']
    })
    this.getExamNotificationForClg();
    this.getCollegeDetailsByID();
    this.getScholarShipOfClg();
    this.getLatestBlogs();
    this.getQueAnsAboutScholarships();
    this.getInfrastructureRating();
  }

  openImageDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  close() {
    this.dialog.closeAll();
  }


  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      this.cityid = res.college_detail[0].cityid;
      // console.log(this.cityid)
      this.getPopularClgByLocation();
      this.category = res.college_detail[0].category;
      this.categoryId = res.college_detail[0].categoryid;
      this.getCollegesAccordingCategory();
      // this.Estd = res.college_detail[0].estd;
      // this.location = res.college_detail[0].city;
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      // this.logo = res.college_detail[0].logo;
      // this.CoursesArr = res.college_detail[0].Courses;
      // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
      // this.table_of_contentArr = res.table_of_content;
      // this.whats_new = ((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;
    });
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }

  postQuestion() {
    this.CompareclgService.postQuestion(this.collegeId, this.course_category, this.course, '22', this.studentForum.value.studentque).subscribe(res => {
      console.log(res);
      // this.QAform.reset();
    })
  }

  getScholarShipOfClg() {
    this.CompareclgService.getScholarShipOfClg(this.collegeId).subscribe(res => {
      // console.log(res);
      this.scholarship_dataArr = res.scholarship_data;
      this.scholarship_data = res.scholarship_data[0].scholarship;
      // this.ScholorshipFAQsArr = res.Commonaly_Asked_Questions;
    })
  }

  getArticleDetails(BlogId) {
    this.router.navigate(['/articledetails', BlogId])
  }

  getQueAnsAboutScholarships() {
    this.CompareclgService.getQueAnsAboutScholarships(this.collegeId).subscribe(res => {
      // console.log(res);
      this.QueAnsAboutScholarshipArr = res.QueAnsAboutScholarship;
    })
  }

  getInfrastructureRating() {
    this.CompareclgService.getInfrastructureRating(this.collegeId).subscribe(res => {
      // console.log(res);
      this.totalInfrastructureRate = res.data.totalInfrastructureRate;
      this.infraReviewsArr = res.data.infraReviews;
      this.one2twoRate = res.data.one2twoRate;
      this.two2threeRate = res.data.two2threeRate;
      this.three2fourRate = res.data.three2fourRate;
      this.four2fiveRate = res.data.four2fiveRate;
    })
  }

  generateStars(count: number): string[] {
    const stars: string[] = [];
    const fullStarsCount = Math.floor(count);
    const hasHalfStar = count - fullStarsCount >= 0.5;

    for (let i = 0; i < fullStarsCount; i++) {
      stars.push('mat_solid:star');
    }

    if (hasHalfStar) {
      stars.push('mat_solid:star_half');
    }

    const remainingStars = 5 - stars.length;
    for (let i = 0; i < remainingStars; i++) {
      stars.push('mat_outline:star_border');
    }

    return stars;
  }

  getPopularClgByLocation() {
    this.CompareclgService.getPopularClgByLocation(this.cityid).subscribe(res => {
      // console.log(res);
      this.popularClgByLocArr = res.CollegeListForCompare;
    })
  }


  getCollegesAccordingCategory() {
    this.CompareclgService.getCollegesAccordingCategory(this.collegeId, this.categoryId).subscribe(res => {
      // console.log(res);
      this.CollegesAccordingCategoryArr = res.bestSuitedColleges;
    })
  }

  voteReview(reviewId, userId, value: number) {
    console.log(value);
    this.CompareclgService.voteReview(userId, reviewId, value).subscribe(res => {
      console.log(res)
    })
  }
}
