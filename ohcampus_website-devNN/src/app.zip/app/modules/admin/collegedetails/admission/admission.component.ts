import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import * as xlsx from 'xlsx';

@Component({
  selector: 'app-admission',
  templateUrl: './admission.component.html',
  styleUrls: ['./admission.component.scss']
})
export class AdmissionComponent implements OnInit {
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;
  @ViewChild('ImportantDates', { static: false }) ImportantDates: ElementRef;


  studentForum: FormGroup;
  //DECLARE ARRAYS
  CoursesArr: any = [];
  campusImagesArr: any = [];
  NotificationArr: any = [];
  latest_blogsArr: any = [];
  popular_blogsArr: any = [];
  AdmissionProcessArr: any = [];
  CollegesAccordingCategoryArr: any = [];
  AdmissionProcessFAQArr: any = [];
  EntranceExamsArr: any = [];
  popularClgByLocArr: any = [];
  QueAnsAboutAdmissionsArr: any = [];
  whats_new: SafeHtml;
  expandedStatesCourse: boolean[] = new Array(this.popularClgByLocArr.length).fill(false);
  //DECLARE VARIABLES
  image: any;
  collegeId: any;
  collegename: any;
  currentYear = (new Date()).getFullYear();
  cityid: any;
  category: any;
  categoryId: any;
  course_category: any;
  course: any;
  sub_category: any;
  tab: number;

  constructor(
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    public CompareclgService: CompareclgService,
    private sanitizer: DomSanitizer,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    this.studentForum = this._formBuilder.group({
      studentque: ['']
    })


    this.getCollegeDetailsByID();
    this.getExamNotificationForClg();
    this.getLatestBlogs();
    this.getCollegeAdmissionProcess();
    this.getPopularClgByLocation();
    this.getCollegesAccordingCategory();
    this.getQueAnsAboutAdmissions();
  }

  openImageDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  close() {
    this.dialog.closeAll();
  }

  onShowCourse(index: number): void {
    this.expandedStatesCourse[index] = !this.expandedStatesCourse[index];
  }

  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      this.cityid = res.college_detail[0].cityid;
      // console.log(this.cityid)
      this.getPopularClgByLocation();
      this.category = res.college_detail[0].category;
      this.categoryId = res.college_detail[0].categoryid;
      this.getCollegesAccordingCategory();
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      // this.logo = res.college_detail[0].logo;
      this.CoursesArr = res.college_detail[0].Courses;
      // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
      // this.table_of_contentArr = res.table_of_content;
      this.whats_new = ((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;
    });
  }

  safeHtml(value) {
    return this.sanitizer.bypassSecurityTrustHtml(value);
  }

  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  getCollegeAdmissionProcess() {
    this.CompareclgService.getCollegeAdmissionProcess(this.collegeId).subscribe(res => {
      this.AdmissionProcessArr = res.AdmissionProcess;
      this.EntranceExamsArr = res.AdmissionProcess.entrance_exams;
      this.AdmissionProcessFAQArr = res.Commonaly_Asked_Questions;

    })
  }

  getPopularClgByLocation() {
    this.CompareclgService.getPopularClgByLocation(this.cityid).subscribe(res => {
      // console.log(res);
      this.popularClgByLocArr = res.CollegeListForCompare;
    })
  }

  getCollegesAccordingCategory() {
    this.CompareclgService.getCollegesAccordingCategory(this.collegeId, this.categoryId).subscribe(res => {
      // console.log(res);
      this.CollegesAccordingCategoryArr = res.bestSuitedColleges;
    })
  }

  getQueAnsAboutAdmissions() {
    this.CompareclgService.getQueAnsAboutAdmissions(this.collegeId).subscribe(res => {
      // console.log(res);
      this.QueAnsAboutAdmissionsArr = res.QueAnsAboutAdmissions;
    })
  }

  getAllanswers(QueId) {
    this.router.navigate(['/allanswers', this.collegeId, QueId]);
  }

  postQuestion() {
    this.CompareclgService.postQuestion(this.collegeId, this.course_category, this.course, '22', this.studentForum.value.studentque).subscribe(res => {
      // console.log(res);
      // this.QAform.reset();
    })
  }

  getExamDetails(examId) {
    console.log(examId);
    this.router.navigate(['/examsdetails', examId])
  }
    //Export to Excel
    exportToExcel() {
      const ws: xlsx.WorkSheet = xlsx.utils.table_to_sheet(this.ImportantDates.nativeElement);
      const wb: xlsx.WorkBook = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
      xlsx.writeFile(wb, 'ImportantDates.xlsx');
    }


    getCoursesBySubcategory(sub_category) {
      // console.log(sub_category);
      this.sub_category = sub_category;
      this.tab = 1;
      this.router.navigate(['/collegeDetails', this.collegeId, 'CoursesFees', this.sub_category]);
      localStorage.setItem('selectedTabIndex', this.tab.toString());
      // this.onTabChange(1);
      // this.route.navigate(['/collegeDetails/' + this.collegeId, this.TabLabel, this.sub_category]);
    }

    getArticleDetails(BlogId) {
      this.router.navigate(['/articledetails', BlogId])
    }

    AdmissionProcessImportantDatesPDF(sub_category){
      this.CompareclgService.AdmissionProcessImportantDatesPDF(this.collegeId,sub_category).subscribe(res=>{
        console.log(res);
        let viewPDF = res;
        window.open(viewPDF.PDF,"_blank")
      })
    }
}
