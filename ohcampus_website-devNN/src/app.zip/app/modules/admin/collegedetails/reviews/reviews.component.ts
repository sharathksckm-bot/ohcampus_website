import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.scss']
})
export class ReviewsComponent implements OnInit {
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;

  collegeId: any;
  reviewsArr: any = [];
  campusImagesArr: any = [];
  NotificationArr: any = [];
  latest_blogsArr: any = [];
  popular_blogsArr: any = [];
  popularClgByLocArr: any = [];
  CollegesAccordingCategoryArr: any = [];
  totalRateCount: any;
  totalPlacementRateCount: any;
  totalInfrastructureRateCount: any;
  totalFacultyRateCount: any;
  totalHostelRateCount: any;
  totalCampusRateCount: any;
  totalMoneyRateCount: any;
  one2twoRate: any;
  two2threeRate: any;
  three2fourRate: any;
  four2fiveRate: any;
  collegename: any;
  cityid: any;
  image: any;
  category: any;
  categoryId: any;

  // fullStars: number = Math.floor(this.totalRateCount); // Full stars
  // halfStar: boolean = this.totalRateCount % 1 !== 0; // Half star if rating is not an integer
  // emptyStars: number = 5 - Math.ceil(this.totalRateCount); // Empty stars

  // starIcons: string[] = [];
  constructor(
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    public CompareclgService: CompareclgService,
    public dialog: MatDialog,
    // public LoginpopupService: LoginpopupService,
    private sanitizer: DomSanitizer,
    private _formBuilder: FormBuilder,
    private el: ElementRef
  ) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    this.getReviewDetails();
    this.getCollegeDetailsByID();
    this.getExamNotificationForClg();
    this.getLatestBlogs();
    // this.generateStarIcons();
  }


  openImageDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  close() {
    this.dialog.closeAll();
  }

  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      // this.cityid = res.college_detail[0].cityid;
      this.cityid = res.college_detail[0].cityid;
      // console.log(this.cityid)
      this.getPopularClgByLocation()
      this.category = res.college_detail[0].category;
      this.categoryId = res.college_detail[0].categoryid;
      this.getCollegesAccordingCategory();
      // this.Estd = res.college_detail[0].estd;
      // this.location = res.college_detail[0].city;
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      // this.logo = res.college_detail[0].logo;
      // this.CoursesArr = res.college_detail[0].Courses;
      // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
      // this.table_of_contentArr = res.table_of_content;
      // // this.whats_new=res.college_detail[0].what_new;
      // this.whats_new = this.safeHtml((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;

    });
  }

  getReviewDetails() {
    this.CompareclgService.getReviewDetails(this.collegeId).subscribe(res => {
      console.log(res);
      // this.reviewsArr = res.data;
      this.reviewsArr = res.data.reviews;
      this.totalRateCount = res.data.totalRateCount;
      this.totalPlacementRateCount = res.data.totalPlacementRateCount;
      this.totalInfrastructureRateCount = res.data.totalInfrastructureRateCount;
      this.totalFacultyRateCount = res.data.totalFacultyRateCount;
      this.totalHostelRateCount = res.data.totalHostelRateCount;
      this.totalCampusRateCount = res.data.totalCampusRateCount;
      this.totalMoneyRateCount = res.data.totalMoneyRateCount;
      this.one2twoRate = res.data.one2twoRate;
      this.two2threeRate = res.data.two2threeRate;
      this.three2fourRate = res.data.three2fourRate;
      this.four2fiveRate = res.data.four2fiveRate;
      // this.generateStarIcons(this.totalRateCount);
    })
  }

  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }


  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId ).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  getArticleDetails(BlogId) {
    this.router.navigate(['/articledetails', BlogId])
  }

  // generateStarIcons(count: number): string[] {
  // const  fullStars = Math.floor(rateCount); 
  // const halfStar = rateCount % 1 !== 0; 
  // const emptyStars = 5 - Math.ceil(rateCount); 
  // const starIcons :string[]=[];
  //   // Add full stars
  //   for (let i = 0; i < fullStars; i++) {
  //     starIcons.push('mat_solid:star');
  //   }

  //   // Add half star if applicable
  //   if (halfStar) {
  //     starIcons.push('mat_solid:star_half');
  //   }

  //   // Add empty stars
  //   for (let i = 0; i < emptyStars; i++) {
  //     starIcons.push('mat_solid:star_border');
  //   }
  // }

  // generateStarArray(rateCount: number): number[] {
  //   const fullStars = Math.floor(rateCount);
  //   const halfStar = rateCount - fullStars >= 0.5 ? 1 : 0;
  //   const emptyStars = 5 - fullStars - halfStar;
  //   return Array(fullStars).fill(1).concat(Array(halfStar).fill(0.5)).concat(Array(emptyStars).fill(0));
  // }

  generateStars(count: number): string[] {
    const stars: string[] = [];
    const fullStarsCount = Math.floor(count);
    const hasHalfStar = count - fullStarsCount >= 0.5;

    for (let i = 0; i < fullStarsCount; i++) {
      stars.push('mat_solid:star');
    }

    if (hasHalfStar) {
      stars.push('mat_solid:star_half');
    }

    const remainingStars = 5 - stars.length;
    for (let i = 0; i < remainingStars; i++) {
      stars.push('mat_outline:star_border');
    }

    return stars;
  }

  voteReview(reviewId, userId, value: number) {
    console.log(value);
    this.CompareclgService.voteReview(userId, reviewId, value).subscribe(res => {
      console.log(res)
    })
  }

  reviewrating() {
    this.router.navigate(['/reviewrating', this.collegeId]);
  }

  getPopularClgByLocation() {
    this.CompareclgService.getPopularClgByLocation(this.cityid).subscribe(res => {
      // console.log(res);
      this.popularClgByLocArr = res.CollegeListForCompare;
    })
  }

  getCollegesAccordingCategory() {
    this.CompareclgService.getCollegesAccordingCategory(this.collegeId, this.categoryId).subscribe(res => {
      // console.log(res);
      this.CollegesAccordingCategoryArr = res.bestSuitedColleges;
    })
  }
}
