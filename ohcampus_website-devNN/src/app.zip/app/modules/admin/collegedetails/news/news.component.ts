import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;

  studentForum:FormGroup;
  latest_blogsArr: any = [];
  popular_blogsArr: any = [];
  campusImagesArr: any = [];
  NotificationArr: any = [];
  reviewsArr: any = [];
  collegeId: any;
  collegename: any;
  image: any;
  totalRateCount: any;
  totalPlacementRateCount: any;
  totalInfrastructureRateCount: any;
  totalFacultyRateCount: any;
  totalHostelRateCount: any;
  totalMoneyRateCount: any;
  totalCampusRateCount: any;
  one2twoRate: any;
  two2threeRate: any;
  three2fourRate: any;
  four2fiveRate: any;
  course_category: any;
  course: any;

  constructor(
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    public CompareclgService: CompareclgService,
    private sanitizer: DomSanitizer,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    this.studentForum = this._formBuilder.group({
      studentque: ['']
    })
    this.getLatestBlogs();
    this.getCollegeDetailsByID();
    this.getExamNotificationForClg();
    this.getReviewDetails();
  }

  openImageDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  close() {
    this.dialog.closeAll();
  }

  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      // this.Estd = res.college_detail[0].estd;
      // this.location = res.college_detail[0].city;
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      // this.logo = res.college_detail[0].logo;
      // this.CoursesArr = res.college_detail[0].Courses;
      // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
      // this.table_of_contentArr = res.table_of_content;
      // this.whats_new = ((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;
    });
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })

  }

  getReviewDetails() {
    this.CompareclgService.getReviewDetails(this.collegeId).subscribe(res => {
      // console.log(res);
      // this.reviewsArr = res.data;
      this.reviewsArr = res.data.reviews;
      this.totalRateCount = res.data.totalRateCount;
      this.totalPlacementRateCount = res.data.totalPlacementRateCount;
      this.totalInfrastructureRateCount = res.data.totalInfrastructureRateCount;
      this.totalFacultyRateCount = res.data.totalFacultyRateCount;
      this.totalHostelRateCount = res.data.totalHostelRateCount;
      this.totalCampusRateCount = res.data.totalCampusRateCount;
      this.totalMoneyRateCount = res.data.totalMoneyRateCount;
      this.one2twoRate = res.data.one2twoRate;
      this.two2threeRate = res.data.two2threeRate;
      this.three2fourRate = res.data.three2fourRate;
      this.four2fiveRate = res.data.four2fiveRate;
      // this.generateStarIcons(this.totalRateCount);
    })
  }

  generateStars(count: number): string[] {
    const stars: string[] = [];
    const fullStarsCount = Math.floor(count);
    const hasHalfStar = count - fullStarsCount >= 0.5;
  
    for (let i = 0; i < fullStarsCount; i++) {
      stars.push('mat_solid:star');
    }
  
    if (hasHalfStar) {
      stars.push('mat_solid:star_half');
    }
  
    const remainingStars = 5 - stars.length;
    for (let i = 0; i < remainingStars; i++) {
      stars.push('mat_outline:star_border');
    }
  
    return stars;
  }

  postQuestion() {
    this.CompareclgService.postQuestion(this.collegeId, this.course_category, this.course, '22', this.studentForum.value.studentque).subscribe(res => {
      // console.log(res);
      // this.QAform.reset();
    })
  }

  getArticleDetails(BlogId) {
    this.router.navigate(['/articledetails', BlogId])
  }
}
