import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';

@Component({
  selector: 'app-compare',
  templateUrl: './compare.component.html',
  styleUrls: ['./compare.component.scss']
})
export class CompareComponent implements OnInit {
  @ViewChild('popupinfo') popupinfo: TemplateRef<any>;
  selectCollegeForm: FormGroup
  collegename: any;
  cityid: any;
  campusImagesArr: any;
  collegeId: any;
  searchclg: any;
  collageListArr: any = [];
  selectedcollage: any;
  logo: any;
  comparedata: boolean = true;
  featuredClgArr:any=[];
  NotificationArr:any=[];
  latest_blogsArr:any=[];
  popular_blogsArr:any=[];

  constructor(public dialog: MatDialog, private router: Router, private _activatedRoute: ActivatedRoute, private fb: FormBuilder, public CompareclgService: CompareclgService) {

  }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    this.getCollegeDetailsByID();
    this.getCollegeListForCompare();
    this.getExamNotificationForClg();
    this.getLatestBlogs();
    this.selectCollegeForm = this.fb.group({
      search_college: ['']
    })

  }
  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      this.cityid = res.college_detail[0].cityid;
      // console.log(this.cityid)
      // this.getOtherCollegesOfferingSameCourseInSameCity();
      // this.Estd = res.college_detail[0].estd;
      // this.location = res.college_detail[0].city;
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      this.logo = res.college_detail[0].logo;
      // this.CoursesArr = res.college_detail[0].Courses;
      // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
      // this.table_of_contentArr = res.table_of_content;
      // // this.whats_new=res.college_detail[0].what_new;
      // this.whats_new = this.safeHtml((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;

    });
  }

  getCompareTab() {
    this.router.navigate(['/collegeDetails/' + this.collegeId + '/compare/comparecollege/compareDetails']);
  }

  getCollegeListForCompare() {
    this.CompareclgService.getCollegeListForCompare(this.searchclg).subscribe(res => {
      // console.log(res)
      this.collageListArr = res.CollegeListForCompare;
    })
  }

  searchCollegeList() {
    this.CompareclgService.getCollegeListForCompare(this.selectCollegeForm.value.search_college).subscribe(res => {
      // console.log(res)
      this.collageListArr = res.CollegeListForCompare;
    })
  }

  AddClg() {
    this.dialog.open(this.popupinfo);
  }

  clgList(collegename, collegeid) {
  
    this.selectedcollage = collegename;
    this.popupClose();
    this.comparedata = false;
  }
  popupClose() {
    this.dialog.closeAll();
    // this.coolegeList = true;
    // this.collegeForm = false;
  }

  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  getArticleDetails(BlogId) {
    this.router.navigate(['/articledetails', BlogId])
  }
}
