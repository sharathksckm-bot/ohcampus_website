import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControlName, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import { AuthService } from 'app/core/auth/auth.service';
import { LoginpopupService } from 'app/shared/loginpopup.service';

@Component({
    selector: 'app-question-ans',
    templateUrl: './question-ans.component.html',
    styleUrls: ['./question-ans.component.scss']
})
export class QuestionAnsComponent implements OnInit {
    @ViewChild('questionSection') questionSection: ElementRef;
    @ViewChild('callAPIDialogapply') callAPIDialogapply: TemplateRef<any>;

    applicationForm: FormGroup;
    QAform: FormGroup;
    readmore: boolean = false;
    readmore1: boolean = false;
    readmore2: boolean = false;
    readmore3: boolean = false;
    collegename: any;
    collegeId: any;
    Estd: any;
    Collage_category: any;
    CourseCategoryArr: any = [];
    CoursesArr: any = [];
    QaCollegeArr: any = [];
    UnAnsweredQueArr: any = [];
    isFollowing: boolean[] = new Array(this.QaCollegeArr.length).fill(false);
    isHovered: boolean[] = [];
    isClicked: boolean[] = [];
    isHovered2: boolean[] = [];
    isClicked2: boolean[] = [];
    CoursesByCatArr: boolean[] = [];
    examListArr: boolean[] = [];
    CourseByCatArr: boolean[] = [];

    page: number = 1; pageSize: number = 10; startNum: number = 0; sortValue: string = "desc";
    totalQuestion: any;
    application_link: any;
    tab: number;

    constructor(
        private router: Router,
        private _activatedRoute: ActivatedRoute,
        public CompareclgService: CompareclgService,
        public authService: AuthService,
        public LoginpopupService: LoginpopupService,
        private sanitizer: DomSanitizer,
        private _formBuilder: FormBuilder,
        private el: ElementRef,
        public dialog: MatDialog,

    ) { }

    ngOnInit(): void {
        const routeParams = this._activatedRoute.snapshot.params;
        // console.log(routeParams);
        this.collegeId = routeParams.id;

        this.QAform = this._formBuilder.group({
            course_category: ['', Validators.required],
            course: ['', Validators.required],
            questionInput: ['']
        }),

            this.applicationForm = this._formBuilder.group({
                name: ['', Validators.required],
                mobileno: ['', Validators.required],
                email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
                course_category: ['', Validators.required],
                college: ['', Validators.required],
                course: ['', Validators.required],
                exam: ['', Validators.required],
                expected_rank: ['', Validators.required],
                expected_score: ['', Validators.required]
            })

        this.getCollegeDetailsByID();
        this.getCourseCategory();
        this.getQAofCollege();
        this.getUnAnsweredQueofCollege();
        this.getExamList();
    }

    getCollegeDetailsByID(): void {
        this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
            // console.log(res);
            this.collegename = res.college_detail[0].title;
            this.Estd = res.college_detail[0].estd;
            // this.location = res.college_detail[0].city;
            this.Collage_category = res.college_detail[0].Collage_category;
            this.application_link = res.application_link;
            // this.logo = res.college_detail[0].logo;
            // this.CoursesArr = res.college_detail[0].Courses;
            // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
            // this.table_of_contentArr = res.table_of_content;
            // this.whats_new = ((res.college_detail[0].what_new));
            // this.campusImagesArr = res.college_images;
            this.getTotalQuestionForCollege();
        });
    }


    getTotalQuestionForCollege() {
        this.CompareclgService.getTotalQuestionForCollege(this.collegeId).subscribe(res => {
            // console.log(res);
            this.totalQuestion = res.totalQuestion.TOTALQUESTION;
            // console.log(this.totalQuestion)
        })
    }
    onPageChange(event) {
        // console.log(event.pageIndex);
        this.page = event.pageIndex + 1;
        this.startNum = (this.pageSize * (event.pageIndex));
        this.getQAofCollege();
    }

    onPageChangeUn(event) {
        // console.log(event.pageIndex);
        this.page = event.pageIndex + 1;
        this.startNum = (this.pageSize * (event.pageIndex));
        this.getUnAnsweredQueofCollege();
    }


    scrollToQuestion() {
        if (this.questionSection && this.questionSection.nativeElement) {
            this.questionSection.nativeElement.scrollIntoView({ behavior: 'smooth' });
        }
    }
    onLoginButtonClick(): void {
        // Check if the user is not logged in, then open the login popup
        if (!this.authService.isLoggedIn()) {
            this.LoginpopupService.openLoginPopup();
        }
    }

    readMore() {
        this.readmore = true;
    }

    readLess() {
        this.readmore = false;
    }

    readMore1() {
        this.readmore1 = true;
    }

    readLess1() {
        this.readmore1 = false;
    }

    readMore2() {
        this.readmore2 = true;
    }

    readLess2() {
        this.readmore2 = false;
    }

    readMore3() {
        this.readmore3 = true;
    }

    readLess3() {
        this.readmore3 = false;
    }

    getCourseCategory() {
        this.CompareclgService.getCourseCategory().subscribe(res => {
            // console.log(res);
            this.CourseCategoryArr = res.data;
        })
    }

    // getCourseByCategory() {
    //     this.CompareclgService.getCourseByCategory(this.QAform.value.course_category).subscribe(res => {
    //         // console.log(res);
    //         this.CoursesArr = res.data;
    //     })
    // }


    getCourseByCategoryClg() {
        this.CompareclgService.getCourseByCategoryClg(this.QAform.value.course_category, this.collegeId).subscribe(res => {
            console.log(res);
            this.CoursesArr = res.data

        })
    }

    getQAofCollege(): void {
        this.CompareclgService.getQAofCollege(this.pageSize, this.page, this.collegeId).subscribe(res => {
            // console.log(res);
            this.QaCollegeArr = res.response_data;
            // console.log(this.QaCollegeArr)
            if (res.response_message == 'Failed') {
                this.QaCollegeArr = [];
            }
        })
        // getUnAnsweredQueofCollege
    }

    getUnAnsweredQueofCollege() {
        this.CompareclgService.getUnAnsweredQueofCollege(this.pageSize, this.page, this.collegeId).subscribe(res => {
            // console.log(res);
            this.UnAnsweredQueArr = res.response_data;
        })
        // getUnAnsweredQueofCollege
    }

    getAllanswers(QueId) {
        this.router.navigate(['/allanswers', this.collegeId, QueId]);
    }

    postQuestion() {
        if (!this.authService.isLoggedIn()) {
            this.LoginpopupService.openLoginPopup();
        }
        else {
            this.CompareclgService.postQuestion(this.collegeId, this.QAform.value.course_category, this.QAform.value.course, '22', this.QAform.value.questionInput).subscribe(res => {
                console.log(res);
                // this.QAform.reset();
            })
        }
    }

    followQuestion(action: string, answerId: any, index: number): void {
        if (action === 'follow') {
            this.isFollowing[index] = !this.isFollowing[index];
        } else if (action === 'unfollow') {
            this.isFollowing[index] = !this.isFollowing[index];
        }
        this.CompareclgService.followQuestion(action, '1', answerId).subscribe(res => {
            console.log(res);
            this.getQAofCollege();
        })
    }

    followUnAnsQuestion(action: string, answerId: any, index: number): void {
        if (action === 'follow') {
            this.isFollowing[index] = !this.isFollowing[index];
        } else if (action === 'unfollow') {
            this.isFollowing[index] = !this.isFollowing[index];
        }
        this.CompareclgService.followQuestion(action, '1', answerId).subscribe(res => {
            console.log(res);
            this.getUnAnsweredQueofCollege();
        })
    }


    voteAnswere(action: string, answerId: any, index: number) {
        if (action == 'like') {
            this.isClicked[index] = !this.isClicked[index];

        }
        if (action == 'dislike') {
            this.isClicked2[index] = !this.isClicked2[index];
        }
        this.CompareclgService.voteAnswere(action, answerId, '1').subscribe(res => {
            // console.log(res);
            this.getQAofCollege();
        })
    }

    getCourseByCategorybyClg() {
        console.log(this.applicationForm.value.course_category)
        this.CompareclgService.getCourseByCategoryClg(this.applicationForm.value.course_category, this.collegeId).subscribe(res => {
            // console.log(res);
            this.CourseByCatArr = res.data

        })
    }

    //   getCourseByCategoryClg2() {
    //     this.CompareclgService.getCourseByCategoryClg(this.predictAdmForm.value.course_category, this.collegeId).subscribe(res => {
    //       // console.log(res);
    //       this.CoursesByCatArr = res.data

    //     })
    //   }

    getExamList() {
        // this.ExamLoader = true;
        this.CompareclgService.getExamList('').subscribe(res => {
            // console.log(res);
            // this.ExamLoader = false;
            this.examListArr = res.response_data;
        })
    }

    apply() {
        if (!this.authService.isLoggedIn()) {
            this.LoginpopupService.openLoginPopup();
        }
        else
        {
        if (this.application_link != null) {
            window.open(this.application_link)
        }
        else {
            const dialogRef = this.dialog.open(this.callAPIDialogapply);
            console.log(this.collegename)
            this.applicationForm.get('college').setValue(this.collegename);
            dialogRef.afterClosed().subscribe((result) => { });

        }
    }
    }

    close() {
        this.dialog.closeAll();
    }

    savCourseApplication() {
        if (this.applicationForm.invalid) {
            this.applicationForm.markAllAsTouched();
            return
        }
        if (this.applicationForm.valid) {
            this.CompareclgService.savCourseApplication(
                this.applicationForm.controls.name.value,
                this.applicationForm.controls.email.value,
                this.applicationForm.controls.mobileno.value,
                this.applicationForm.controls.course_category.value,
                this.collegeId,
                this.applicationForm.controls.course.value,
                this.applicationForm.controls.exam.value,
                this.applicationForm.controls.expected_rank.value,
                this.applicationForm.controls.expected_score.value,
            ).subscribe(res => {
                console.log(res);
                this.close();
            })
        }
    }


    //--------------------only Numbers are allowed---------------------//
    numberOnly(event): boolean {
        // console.log(event.target.value)
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }

    getCollegeInfo() {
        this.tab = 0;
        this.router.navigate(['/collegeDetails', this.collegeId,]);
        localStorage.setItem('selectedTabIndex', this.tab.toString());
    }

    getCoursesFees() {
        this.tab = 1;
        this.router.navigate(['/collegeDetails', this.collegeId, 'CoursesFees']);
        localStorage.setItem('selectedTabIndex', this.tab.toString());
    }

    getReviews() {
        this.tab = 0;
        this.router.navigate(['/collegeDetails', this.collegeId,]);
        localStorage.setItem('selectedTabIndex', this.tab.toString());
    }
}
