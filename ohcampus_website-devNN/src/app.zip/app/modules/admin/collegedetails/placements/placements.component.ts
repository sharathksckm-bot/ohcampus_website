import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-placements',
  templateUrl: './placements.component.html',
  styleUrls: ['./placements.component.scss']
})
export class PlacementsComponent implements OnInit {
  @ViewChild('callAPIDialog1') callAPIDialog1: TemplateRef<any>;

  collegename: any;
  campusImagesArr:any=[];
  NotificationArr:any=[];
  latest_blogsArr:any=[];
  popular_blogsArr:any=[];
  placementlistArr:any=[];
  popularClgByLocArr:any=[];
  Commonaly_Asked_QuestionsArr:any=[];
  placemeneratingArr:any=[];
  placemeneratingreviewsArr:any=[];
  CollegesAccordingCategoryArr:any=[];
  collegeId: any;
  image: any;
  placementCount: any;
  cityid: any;
  categoryId: any;
  whats_new: any;
  one2twoRate: any;
  two2threeRate: any;
  three2fourRate: any;
  four2fiveRate: any;

  constructor(
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    public CompareclgService: CompareclgService,
    private sanitizer: DomSanitizer,
    public dialog: MatDialog
  ) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    this.getCollegeDetailsByID();
    this.getExamNotificationForClg();
    this.getLastThreeYearsPlacementData();
    this.getPlacementRating();
    this.getLatestBlogs();
  }
  
  openImageDialog(img) {
    const dialogRef = this.dialog.open(this.callAPIDialog1);
    dialogRef.afterClosed().subscribe((result) => { });
    this.image = img;
  }

  close() {
    this.dialog.closeAll();
  }

  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.whats_new = ((res.college_detail[0].what_new));
      this.collegename = res.college_detail[0].title;
      this.cityid = res.college_detail[0].cityid;
      // console.log(this.cityid)
      this.getPopularClgByLocation();
      this.categoryId = res.college_detail[0].categoryid;
      this.getCollegesAccordingCategory();
      // this.Estd = res.college_detail[0].estd;
      // this.location = res.college_detail[0].city;
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      // this.logo = res.college_detail[0].logo;
      // this.CoursesArr = res.college_detail[0].Courses;
      // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
      // this.table_of_contentArr = res.table_of_content;
      // this.whats_new = ((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;
    });
  }
 getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  
  getArticleDetails(BlogId) {
    this.router.navigate(['/articledetails', BlogId])
  }

  getLastThreeYearsPlacementData(){
    this.CompareclgService.getLastThreeYearsPlacementData(this.collegeId).subscribe(res=>{
      // console.log(res);
      this.placementlistArr=res.placementlist;
      this.Commonaly_Asked_QuestionsArr=res.Commonaly_Asked_Questions;
    })
  }

  getPlacementRating(){
    this.CompareclgService.getPlacementRating(this.collegeId).subscribe(res=>{
      console.log(res);
      this.placemeneratingArr=res.data;
      this.placemeneratingreviewsArr=res.data.reviews;
      this.placementCount=res.data.totalPlacementRate;
      this.one2twoRate = res.data.one2twoRate;
      this.two2threeRate = res.data.two2threeRate;
      this.three2fourRate = res.data.three2fourRate;
      this.four2fiveRate = res.data.four2fiveRate;
    })
  }

  generateStars(count: number): string[] {
    const stars: string[] = [];
    const fullStarsCount = Math.floor(count);
    const hasHalfStar = count - fullStarsCount >= 0.5;

    for (let i = 0; i < fullStarsCount; i++) {
      stars.push('mat_solid:star');
    }

    if (hasHalfStar) {
      stars.push('mat_solid:star_half');
    }

    const remainingStars = 5 - stars.length;
    for (let i = 0; i < remainingStars; i++) {
      stars.push('mat_outline:star_border');
    }

    return stars;
  }

  getPopularClgByLocation() {
    this.CompareclgService.getPopularClgByLocation(this.cityid).subscribe(res => {
      // console.log(res);
      this.popularClgByLocArr = res.CollegeListForCompare;
    })
  }

  getCollegesAccordingCategory() {
    this.CompareclgService.getCollegesAccordingCategory(this.collegeId, this.categoryId).subscribe(res => {
      // console.log(res);
      this.CollegesAccordingCategoryArr = res.bestSuitedColleges;
    })
  }

  voteReview(reviewId, userId, value: number) {
    console.log(value);
    this.CompareclgService.voteReview(userId, reviewId, value).subscribe(res => {
      console.log(res)
    })
  }
}
