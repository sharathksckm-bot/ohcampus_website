import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatTabGroup } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-hostel-campus',
  templateUrl: './hostel-campus.component.html',
  styleUrls: ['./hostel-campus.component.scss']
})
export class HostelCampusComponent implements OnInit {
  collegeId: any;
  collegename: any;
  campusImagesArr: any = [];
  NotificationArr: any = [];
  latest_blogsArr: any = [];
  popular_blogsArr: any = [];
  popularClgByLocArr: any = [];
  infraReviewsArr: any = [];
  CollegesAccordingCategoryArr: any = [];
  one2twoRate: any;
  two2threeRate: any;
  three2fourRate: any;
  four2fiveRate: any;
  totalInfrastructureRate: any;
  cityid: any;
  category: any;
  categoryId: any;

  constructor(
    public dialog: MatDialog,
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    public CompareclgService: CompareclgService,
    private tabGroup: MatTabGroup) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.collegeId = routeParams.id;
    this.getCollegeDetailsByID();
    this.getExamNotificationForClg();
    this.getLatestBlogs();
    this.getInfrastructureRating();
  }


  getCollegeDetailsByID() {
    this.CompareclgService.getCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      this.collegename = res.college_detail[0].title;
      this.cityid = res.college_detail[0].cityid;
      // console.log(this.cityid)
      this.getPopularClgByLocation();
      this.category = res.college_detail[0].category;
      this.categoryId = res.college_detail[0].categoryid;
      this.getCollegesAccordingCategory();
      // this.cityid = res.college_detail[0].cityid;
      // console.log(this.cityid)
      // this.getOtherCollegesOfferingSameCourseInSameCity();
      // this.Estd = res.college_detail[0].estd;
      // this.location = res.college_detail[0].city;
      // this.Collage_category = res.college_detail[0].Collage_category;
      // this.image = res.college_detail[0].image;
      // this.logo = res.college_detail[0].logo;
      // this.CoursesArr = res.college_detail[0].Courses;
      // this.CollegeHighlightArr = res.college_detail[0].CollegeHighlight;
      // this.table_of_contentArr = res.table_of_content;
      // // this.whats_new=res.college_detail[0].what_new;
      // this.whats_new = this.safeHtml((res.college_detail[0].what_new));
      this.campusImagesArr = res.college_images;
    });
  }

  getExamNotificationForClg() {
    this.CompareclgService.getExamNotificationForClg(this.collegeId,).subscribe(res => {
      // console.log(res);
      this.NotificationArr = res.response_data;
    })
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs(this.collegeId).subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      this.popular_blogsArr = res.popular_blogs;
    })
  }

  getArticleDetails(BlogId) {
    this.router.navigate(['/articledetails', BlogId])
  }

  getInfrastructureRating() {
    this.CompareclgService.getInfrastructureRating(this.collegeId).subscribe(res => {
      console.log(res);
      this.totalInfrastructureRate = res.data.totalInfrastructureRate;
      this.infraReviewsArr=res.data.infraReviews;
      this.one2twoRate = res.data.one2twoRate;
      this.two2threeRate = res.data.two2threeRate;
      this.three2fourRate = res.data.three2fourRate;
      this.four2fiveRate = res.data.four2fiveRate;
    })
  }

  generateStars(count: number): string[] {
    const stars: string[] = [];
    const fullStarsCount = Math.floor(count);
    const hasHalfStar = count - fullStarsCount >= 0.5;

    for (let i = 0; i < fullStarsCount; i++) {
      stars.push('mat_solid:star');
    }

    if (hasHalfStar) {
      stars.push('mat_solid:star_half');
    }

    const remainingStars = 5 - stars.length;
    for (let i = 0; i < remainingStars; i++) {
      stars.push('mat_outline:star_border');
    }

    return stars;
  }

  getPopularClgByLocation() {
    this.CompareclgService.getPopularClgByLocation(this.cityid).subscribe(res => {
      // console.log(res);
      this.popularClgByLocArr = res.CollegeListForCompare;
    })
  }


  getCollegesAccordingCategory() {
    this.CompareclgService.getCollegesAccordingCategory(this.collegeId, this.categoryId).subscribe(res => {
      // console.log(res);
      this.CollegesAccordingCategoryArr = res.bestSuitedColleges;
    })
  }

  voteReview(reviewId, userId, value: number) {
    console.log(value);
    this.CompareclgService.voteReview(userId, reviewId, value).subscribe(res => {
      console.log(res)
    })
  }
}
