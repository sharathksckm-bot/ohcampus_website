
import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
interface Coursecat {
  value: string;
  viewValue: string;
}
interface States {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-comparecolleges',
  templateUrl: './comparecolleges.component.html',
  styleUrls: ['./comparecolleges.component.scss']
})
export class ComparecollegesComponent implements OnInit {
  @ViewChild('popupinfo') popupinfo: TemplateRef<any>;

  selectCollegeForm: FormGroup;

  coolegeList: boolean = true;
  comparedata: boolean = true;
  comparedata1: boolean = true;
  comparedata2: boolean = true;
  comparedata3: boolean = true;
  collegeForm: boolean = false;
  collegeLoader: boolean = false;
  degreeLoader: boolean = false;
  courseLoader: boolean = false;
  getDAtaLoader: boolean = false;
  showDiv1: boolean = true;

  category_id: any;
  searchValue: any;
  searchText;
  selectedcollage: any;
  pageSize: number = 10;
  start = 0;
  collegeId: any;

  collageListArr: any = [];
  degreeArr: any = [];
  coursesArr: any = [];
  featuredClgArr: any = [];
  RatingArr: any = [];
  RankArr: any = [];
  divType: any;
  collegeName: any;
  courseName: any;
  collegeLocation: any;
  collegeLogo: any;
  Collage_category: any;
  Courses_Count: any;
  estd: any;
  Rating: any;
  NIRF: any;
  indiaTodayRank: any;
  placement_rate: any;
  infrastructure_rate: any;
  faculty_rate: any;
  campus_rate: any;
  money_rate: any;

  constructor(private _formBuilder: FormBuilder, public dialog: MatDialog, private router: Router, public CompareclgService: CompareclgService) {

  }


  ngOnInit(): void {
    this.selectCollegeForm = this._formBuilder.group({
      search_college: ['', Validators.required],
      degree: ['', Validators.required],
      course: ['', Validators.required],
    });
    // this.searchCollegeList();
    this.getFeaturedColleges();
    // this.getCollegedetailtoCompare();
  }

  coursecat: Coursecat[] = [
    { value: 'opt-0', viewValue: 'Engineering' },
    { value: 'opt-1', viewValue: 'Management' },
    { value: 'opt-2', viewValue: 'Arts & Science' },
    { value: 'opt-3', viewValue: 'Agriculture' },
    { value: 'opt-4', viewValue: 'Commerce' },
  ];

  state: States[] = [
    { value: 'opt-0', viewValue: 'Maharashtra' },
    { value: 'opt-1', viewValue: 'Karnataka' },
    { value: 'opt-2', viewValue: 'Uttar Pradesh' },
    { value: 'opt-3', viewValue: 'Andhra Pradesh' },
    { value: 'opt-4', viewValue: 'Gujrat' },
  ];

  modifySelection() {
    this.dialog.open(this.popupinfo);
  }

  AddClg(type) {
    // console.log(type);
    this.divType = type;
    this.dialog.open(this.popupinfo);
    this.selectCollegeForm.reset();
    this.selectedcollage = '';
    this.searchCollegeList();
  }
  popupClose() {
    this.dialog.closeAll();
    this.coolegeList = true;
    this.collegeForm = false;
  }

  clgList(collegename, collegeid) {
    this.coolegeList = false;
    // console.log(collegeid)
    this.collegeId = collegeid;
    this.selectedcollage = collegename;
    this.collegeForm = true;
    this.getDegreeData();
    // console.log(this.selectedcollage);

  }

  toggleDivs(type) {
    if (type == 'first') {
      this.comparedata = true;
    }
    if (type == 'second') {
      this.comparedata1 = true;
    }
    if (type == 'third') {
      this.comparedata2 = true;
    }
    if (type == 'fourth') {
      this.comparedata3 = true;
    }
    // if(this.divType=='two'){
    //   this.comparedata1 = !this.comparedata1;
    // }

    // this.comparedata1 = !this.comparedata1;
    console.log();
  }

  searchCollegeList() {
    this.coolegeList = true;
    this.collegeLoader = true;
    this.category_id = '';
    this.CompareclgService.getCollegelistCompare(this.selectCollegeForm.value.search_college, this.start, this.pageSize,).subscribe(res => {
      // console.log(res);
      this.collegeLoader = false;
      this.collageListArr = res.data;
      // console.log(this.selectCollegeForm);
    })

  }

  gotoQuote() {
    // console.log(this.selectCollegeForm);
    // this.getCollegedetailtoCompare();
    this.dialog.closeAll();
    // this.selectCollegeForm.reset();
    // console.log(this.divType);
    if (this.divType == 'one') {
      this.getCollegedetailtoCompare();
      // this.getCollegedetailtoCompare();

      this.comparedata = false;

    }
    if (this.divType == 'two') {
      // alert(7)
      this.comparedata1 = false;
    }
    if (this.divType == 'three') {
      // alert(7)
      this.comparedata2 = false;
    }
    if (this.divType == 'four') {
      // alert(7)
      this.comparedata3 = false;
    }
    this.searchCollegeList();
  }

  //getDegreeList
  getDegreeData() {
    this.degreeLoader = true;;
    this.CompareclgService.getLevelById(this.collegeId).subscribe(res => {
      this.degreeLoader = false;
      // console.log(res);
      this.degreeArr = res.data;

      // console.log(this.selectCollegeForm)
    })
  }

  //getcourseList
  getcourseData() {
    // console.log(this.selectCollegeForm.value.degree)
    this.courseLoader = true;
    this.CompareclgService.getCoursesbyCollege(this.selectCollegeForm.value.degree, this.collegeId).subscribe(res => {
      // console.log(res);
      this.courseLoader = false;
      this.coursesArr = res.data;
    })

  }
  //gET fEATURED cOLEGE List
  getFeaturedColleges() {
    this.CompareclgService.CompareCollege().subscribe(res => {
      // console.log(res);
      this.featuredClgArr = res.data;
      // this.featuredClgArr.slice(0, 8);
    })
  }

  //gET college data 
  getCollegedetailtoCompare() {
    // this.getDAtaLoader = true;
    this.CompareclgService.getcompareCollegeDetailsByID(this.collegeId).subscribe(res => {
      // console.log(res);
      // this.getDAtaLoader = false;
      this.collegeName = res.college_detail[0].title;
      this.courseName = this.selectCollegeForm.value.course;
      this.collegeLocation = res.college_detail[0].city;
      this.collegeLogo = res.college_detail[0].logo;
      this.Collage_category = res.college_detail[0].Collage_category;
      this.Courses_Count = res.college_detail[0].Courses_Count;
      this.estd = res.college_detail[0].estd;
      this.Rating = res.college_detail[0].Rating;
      this.RankArr = res.college_detail[0].Rank;
      this.RankArr.forEach(element => {
        this.NIRF = element.rank;
        this.indiaTodayRank = element.rank;
      });
      this.placement_rate = res.college_detail[0].ReviewRating[0].placement_rate;
      this.infrastructure_rate = res.college_detail[0].ReviewRating[0].infrastructure_rate;
      this.faculty_rate = res.college_detail[0].ReviewRating[0].faculty_rate;
      this.campus_rate = res.college_detail[0].ReviewRating[0].campus_rate;
      this.money_rate = res.college_detail[0].ReviewRating[0].money_rate;
      console.log(this.placement_rate);

    })
  }
}
