import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-loans',
  templateUrl: './loans.component.html',
  styleUrls: ['./loans.component.scss']
})
export class LoansComponent implements OnInit {
  searchLoanForm: FormGroup;
  loanArr: any = [];

  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {

    this.searchLoanForm = this._formBuilder.group({
      seachvalue: [''],
    })
    this.getLoans();
  }

  getLoans() {
    this.CompareclgService.getLoans(this.searchLoanForm.value.seachvalue).subscribe(res => {
      console.log(res);
      this.loanArr = res.data;
    })
  }
}
