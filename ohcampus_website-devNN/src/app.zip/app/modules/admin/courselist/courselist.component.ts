import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-courselist',
  templateUrl: './courselist.component.html',
  styleUrls: ['./courselist.component.scss']
})
export class CourselistComponent implements OnInit {

  searchCourseForm: FormGroup;
  courseListArr: any = [];
  page: number = 1; pageSize: number = 10; startNum: number = 0; sortValue: string = "desc";
  order: any = [
    {
      "column": 0,
      "dir": "desc"
    }
  ];
  start: number = 0;
  recordsTotal: any;
  searchedcourse: any;

  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder

  ) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    console.log(routeParams);
    this.searchedcourse = routeParams.searchedcourse;

    this.searchCourseForm = this._formBuilder.group({
      course: ['']
    })

    if (this.searchedcourse == undefined) {
      this.getAllCourseList();
    }
    else {
      this.getAllCourseListsearch();
    }

  }

  getAllColleges(courseid) {
    console.log(courseid)
    this.route.navigate(['allCollegeList/course', courseid]);
  }

  getAllCourseList() {
    let searchData = {
      value: this.searchCourseForm.value.course
    }
    this.CompareclgService.getAllCourseList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
      // console.log(res);
      this.courseListArr = res.data;
      this.recordsTotal = res.recordsFiltered;
    })
  }

  searchCourseList(event) {
    console.log(event)
    let searchData = {
      value: event
    }
    this.CompareclgService.getAllCourseList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
      // console.log(res);
      this.courseListArr = res.data;
      this.recordsTotal = res.recordsFiltered;
    })
  }

  getAllCourseListsearch() {
    let searchData = {
      value: this.searchedcourse
    }
    this.CompareclgService.getAllCourseList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
      // console.log(res);
      this.courseListArr = res.data;
      this.recordsTotal = res.recordsFiltered;
    })
  }

  onPageChange(event) {
    // console.log(event.pageIndex);
    this.page = event.pageIndex + 1;
    this.startNum = (this.pageSize * (event.pageIndex));
    // this.collegeLoader = false;
    let searchData = {
      value: ''
    }
    this.CompareclgService.getAllCourseList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
      // this.collegeLoader = false;
      this.recordsTotal = res.recordsFiltered;
      if (res.response_code == 2) {
        Swal.fire('', res.response_message, 'warning');
        // this.paginatedCollegeData = [];
        return
      }
      else {
        // console.log(res);
        this.courseListArr = res.data;
        // this.paginatedCollegeData = this.collegeArr.slice(0, this.pageSize);
      }

    })
  }
}
