import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';

@Component({
  selector: 'app-articledetails',
  templateUrl: './articledetails.component.html',
  styleUrls: ['./articledetails.component.scss']
})
export class ArticledetailsComponent implements OnInit {

  @ViewChild('EnqFormNgForm') EnqFormNgForm: NgForm;

  BlogId: any;
  blogtitle: any;
  blogdescription: any;
  blogimage: any;
  relatedblogArr: any = [];
  blogcategoryArr: any = [];
  latest_blogsArr: any = [];
  EnqForm: FormGroup;
  showInquiryMsg: any;
  category_name: any;

  constructor(public CompareclgService: CompareclgService, private _activatedRoute: ActivatedRoute, private route: Router, private _formBuilder: FormBuilder,) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.BlogId = routeParams.BlogId;

    this.EnqForm = this._formBuilder.group({
      name: ['', Validators.required],
      email: ['',[Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      phone_no: ['', Validators.required],
      message: ['', Validators.required],

    })
    this.getBlogsDetails();
    this.getBlogCategory();
    this.getLatestBlogs();
  }
  
  getBlogsDetails() {
    this.CompareclgService.getBlogsDetails(this.BlogId).subscribe(res => {
      // console.log(res);
      this.blogtitle = res.blogdetails[0].title;
      this.blogdescription = res.blogdetails[0].description;
      this.category_name = res.blogdetails[0].category_name;
      this.blogimage = res.blogdetails[0].image;
      this.relatedblogArr = res.relatedblog;
    })
  }

  //--------------------only Numbers are allowed---------------------//
  numberOnly(event): boolean {
    console.log(event.target.value)
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  getBlogCategory() {
    this.CompareclgService.getBlogCategory().subscribe(res => {
      // console.log(res);
      this.blogcategoryArr = res.blogcategory;
    })
  }

  getBlogByCat(catId) {
    this.route.navigate(['/exams', 1, catId]);
  }

  saveEnquiry() {
    this.CompareclgService.saveEnquiry(
      this.EnqForm.value.name,
      this.EnqForm.value.email,
      this.EnqForm.value.phone_no,
      this.EnqForm.value.message,
      this.BlogId,
      'blogs'
    ).subscribe(res => {
      this.showInquiryMsg = res.response_message
      console.log(res);
      this.EnqFormNgForm.resetForm();
      // this.EnqForm.reset();
      // this.clearFormErrors(this.EnqForm);
    })
  }

  clearFormErrors(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((key) => {
      formGroup.get(key).setErrors(null);
    });
  }

  getLatestBlogs() {
    this.CompareclgService.getLatestBlogs('').subscribe(res => {
      // console.log(res);
      this.latest_blogsArr = res.latest_blogs;
      // this.popular_blogsArr = res.popular_blogs;
    })
  }
}
