import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'app/core/auth/auth.service';
import { LoginpopupService } from 'app/shared/loginpopup.service';

// import { access } from 'fs';
@Component({
  selector: 'app-allcolleges',
  templateUrl: './allcolleges.component.html',
  styleUrls: ['./allcolleges.component.scss']
})
export class AllcollegesComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('callAPIDialogpredictAdm') callAPIDialogpredictAdm: TemplateRef<any>;
  @ViewChild('callsignInForm') callsignInForm: TemplateRef<any>;


  AllCollegesForm: FormGroup;
  predictAdmForm: FormGroup;

  //DECLARE ARRAYS
  LocationArr: any = []; rankCatArr: any = []; courseDataArr: any = []; OwnershipArr: any = []; paginatedCollegeData: any = []; collegeArr: any = []; CourseCategoryArr: any = []; CoursesByCatArr: any = []
  examListArr: any = []; RatingArr: any = [];

  //DECLARE VARIABLES
  searchdata: any; searchcoursedata: any; searchownership: any; selectedcity: any; panelOpenState = false; coursSelected: any; ownerShipselected: any; searchValue: any;
  res_Status: any; start: number = 0; totalColleges: any; page: number = 1; pageSize: number = 5; startNum: number = 0; sortValue: string = "desc";
  locationSelected: any; ownershipSelected: any; collageID: any; LocId: any;

  //Loaders
  locLoader: boolean = false; courseLoader: boolean = false; ownershipLoader: boolean = false; collegeLoader: boolean = false;
  order: any = [
    {
      "column": 0,
      "dir": "desc"
    }
  ];
  tab: number;
  application_link: null;
  collegename: any;
  collegename1: any;
  collegeid: any;
  courseid: any;
  catid: any;
  selectedcategory: string;
  selectedcityid: string;
  token: string;


  constructor(
    public CompareclgService: CompareclgService,
    private _formBuilder: FormBuilder,
    private route: Router,
    private _activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    public authService: AuthService,
    public LoginpopupService: LoginpopupService,
  ) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    console.log(routeParams)
    this.catid = routeParams.catid;
    this.LocId = routeParams.id;
    this.courseid = routeParams.courseid;
    this.searchValue = routeParams.searchvalue;
   
    this.selectedcityid = localStorage.getItem('cityId')
    this.selectedcategory = localStorage.getItem('categoryId')
    // console.log(this.LocId);
    this._activatedRoute.params.subscribe((params) => {
      this.selectedcityid = localStorage.getItem('cityId')
      this.selectedcategory = localStorage.getItem('categoryId')
      // this.loadData(catid, cityid);
      if (this.searchValue != undefined) {
        this.getcollegebySearch()
      }
      if(this.catid != undefined && this.LocId !=undefined){
        this.getCollegeListforloc();
      }
      this.getCourseCategory();
      this.getExamList();
      this.getRatingList();
    })
    const currentPage = this.route.url;

    // console.log(routeParams);
    this.AllCollegesForm = this._formBuilder.group({
      location: [''],
      course: [''],
      ownership: [''],
      category_id: [''],
      search_value: ['']
    })
    // this.ListOFColleges=this._formBuilder.group({

    // })

    this.predictAdmForm = this._formBuilder.group({
      name: ['', Validators.required],
      mobileno: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      course_category: ['', Validators.required],
      college: ['', Validators.required],
      course: ['', Validators.required],
      exam: ['', Validators.required],
      expected_rank: ['', Validators.required],
      expected_score: ['', Validators.required]
    })

    this.getLocationList();
    this.getRankCategory();
    this.getAllCourseList();
    this.getOwnershipList();
    if (this.LocId == undefined) {
      this.getCollegeList();
    }
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    // this.getCollegeListforloc();
  }

  loadData(catid: string, cityid: string): void {
    this.collegeLoader = true;
    let searchData = {
      clgname: '',
      loc: cityid,
      ownerShip: '',
      rankCategory: '',
      categoryid: catid
    }
    this.CompareclgService.getCollegeList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
      this.collegeLoader = false;
      this.totalColleges = res.recordsFiltered;
      if (res.response_code == 2) {
        Swal.fire('', res.response_message, 'warning');
        // this.paginatedCollegeData = [];
        return
      }
      else {
        this.collegeArr = res.data;
        // console.log(this.collegeArr);
        // this.paginatedCollegeData = this.collegeArr.slice(0, this.pageSize);
      }
    })


  }


  onPageChange(event) {
    if (this.LocId != undefined) {
      this.page = event.pageIndex + 1;
      this.startNum = (this.pageSize * (event.pageIndex));
      this.collegeLoader = false;
      let searchData = {
        clgname: '',
        loc: this.selectedcityid,
        ownerShip: '',
        rankCategory: '',
        categoryid: this.selectedcategory
      }
      this.CompareclgService.getCollegeList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
        this.collegeLoader = false;
        this.totalColleges = res.recordsFiltered;
        if (res.response_code == 2) {
          Swal.fire('', res.response_message, 'warning');
          // this.paginatedCollegeData = [];
          return
        }
        else {
          this.collegeArr = res.data;
          // console.log(this.collegeArr);
          // this.paginatedCollegeData = this.collegeArr.slice(0, this.pageSize);
        }
      })
    }
    else {
      // console.log(this.AllCollegesForm.value.location);
      // console.log(this.AllCollegesForm.value.ownership);
      // console.log(event.pageIndex);
      this.page = event.pageIndex + 1;
      this.startNum = (this.pageSize * (event.pageIndex));
      this.collegeLoader = false;
      let searchData = {
        clgname: this.AllCollegesForm.value.search_value,
        loc: this.locationSelected,
        ownerShip: this.ownershipSelected,
        rankCategory: this.AllCollegesForm.value.category_id,
        categoryid: ''
      }
      this.CompareclgService.getCollegeList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
        this.collegeLoader = false;
        this.totalColleges = res.recordsFiltered;
        if (res.response_code == 2) {
          Swal.fire('', res.response_message, 'warning');
          // this.paginatedCollegeData = [];
          return
        }
        else {
          // console.log(res);
          this.collegeArr = res.data;
          // this.paginatedCollegeData = this.collegeArr.slice(0, this.pageSize);
        }

      })
    }
    // this.page = event.pageIndex + 1;
    // this.pageSize = event.pageSize;
    // // const startIndex = event.pageIndex * this.pageSize;
    // //   const endIndex = startIndex + this.pageSize;
    // //   this.paginatedCollegeData = this.collegeArr.slice(startIndex, endIndex);
    // this.startNum = (this.pageSize * (event.pageIndex))
    // this.getCollegeList();
  }

  getCollegeList() {
    this.collegeLoader = true;
    let searchData = {
      clgname: this.AllCollegesForm.value.search_value,
      loc: this.locationSelected,
      ownerShip: this.ownershipSelected,
      rankCategory: this.AllCollegesForm.value.category_id,
      courseid: this.courseid,
      categoryid: ''
    }
    this.CompareclgService.getCollegeList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
      this.collegeLoader = false;
      this.totalColleges = res.recordsFiltered;
      if (res.response_code == 2) {
        Swal.fire('', res.response_message, 'warning');
        // this.paginatedCollegeData = [];
        return
      }
      else {
        this.collegeArr = res.data;
        // console.log(this.collegeArr);
        // this.paginatedCollegeData = this.collegeArr.slice(0, this.pageSize);
      }

    })
  }


  //--------Get Location List--------//
  getLocationList() {
    this.locLoader = true;
    this.CompareclgService.getCity(this.AllCollegesForm.value.location).subscribe(res => {
      this.locLoader = false;
      this.LocationArr = res.data;
    })
  }

  //Get Rank Category
  getRankCategory() {
    this.CompareclgService.getRankList().subscribe(res => {
      // console.log(res);
      this.rankCatArr = res.data;
    })
  }

  geLocData(event: any, loc, city) {
    // console.log(event);
    // console.log(loc);
    this.selectedcity = city;
    this.locationSelected = loc;
    // this.AllCollegesForm.get('location').setValue(loc);
    // console.log(this.AllCollegesForm);
    this.getCollegeList();
  }

  selectCourse(course) {
    this.coursSelected = course;
  }

  //get all course list
  getAllCourseList() {
    this.searchcoursedata = '';
    this.courseLoader = true;
    this.CompareclgService.getCourseList(this.AllCollegesForm.value.course).subscribe(res => {
      this.courseLoader = false;
      // console.log(res);
      this.courseDataArr = res.data;
    })
  }

  getCollegeDetails(collageID) {
    this.collageID = collageID;
    this.tab = 0;
    this.route.navigate(['/collegeDetails', this.collageID]);
    localStorage.setItem('selectedTabIndex', this.tab.toString());

  }

  //get all data
  getOwnershipList() {
    // alert(67)
    this.ownershipLoader = true;
    this.searchownership = '';
    this.CompareclgService.getOwnershipList(this.AllCollegesForm.value.ownership).subscribe(res => {
      // console.log(res);
      this.ownershipLoader = false;
      this.OwnershipArr = res.data;
    })
  }

  ownerShipSelected(ownership, nmae) {
    this.ownerShipselected = ownership;
    this.ownershipSelected = nmae
    // this.AllCollegesForm.get('ownership').setValue(nmae);
    this.getCollegeList();
  }

  getCollegeListforloc(): void {
    // window.location.reload();
    this.collegeLoader = true;
    let searchData = {
      clgname: '',
      loc: this.selectedcityid,
      ownerShip: '',
      rankCategory: '',
      categoryid: this.selectedcategory
    }
    this.CompareclgService.getCollegeList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
      this.collegeLoader = false;
      this.totalColleges = res.recordsFiltered;
      if (res.response_code == 2) {
        Swal.fire('', res.response_message, 'warning');
        // this.paginatedCollegeData = [];
        return
      }
      else {
        this.collegeArr = res.data;
        // console.log(this.collegeArr);
        // this.paginatedCollegeData = this.collegeArr.slice(0, this.pageSize);
      }
    })
  }


  getcollegebySearch() {
    this.collegeLoader = true;
    let searchData = {
      clgname: this.searchValue,
      loc: '',
      ownerShip: '',
      rankCategory: '',
      categoryid: ''
    }
    this.CompareclgService.getCollegeList(this.page, this.pageSize, this.start, this.order, searchData).subscribe(res => {
      this.collegeLoader = false;
      this.totalColleges = res.recordsFiltered;
      if (res.response_code == 2) {
        Swal.fire('', res.response_message, 'warning');
        // this.paginatedCollegeData = [];
        return
      }
      else {
        this.collegeArr = res.data;
        // console.log(this.collegeArr);
        // this.paginatedCollegeData = this.collegeArr.slice(0, this.pageSize);
      }
    })
  }



  getClgAdmInfo(collageID) {
    this.collageID = collageID;
    this.tab = 3;
    this.route.navigate(['/collegeDetails', this.collageID, 'Admissions']);
    localStorage.setItem('selectedTabIndex', this.tab.toString());
  }

  getClgCourseInfo(collageID) {
    this.collageID = collageID;
    this.tab = 1;
    this.route.navigate(['/collegeDetails', this.collageID, 'CoursesFees']);
    localStorage.setItem('selectedTabIndex', this.tab.toString());
  }

  getClgPlacementInfo(collageID) {
    this.collageID = collageID;
    this.tab = 4;
    this.route.navigate(['/collegeDetails', this.collageID, 'Placements']);
    localStorage.setItem('selectedTabIndex', this.tab.toString());
  }


  //--------------------only Numbers are allowed---------------------//
  numberOnly(event): boolean {
    // console.log(event.target.value)
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  predictAdm(collegeid, collegename) {
    this.collegeid = collegeid
    if (this.application_link != null) {
      // window.open(this.application_link)
    }
    else {
      if (!this.authService.isLoggedIn()) {
        this.LoginpopupService.openLoginPopup();
      }
      else {
        const dialogRef = this.dialog.open(this.callAPIDialogpredictAdm);
        this.predictAdmForm.get('college').setValue(collegename);
        dialogRef.afterClosed().subscribe((result) => { });
      }

    }
  }

  getCourseCategory() {
    this.CompareclgService.getCourseCategory().subscribe(res => {
      // console.log(res);
      this.CourseCategoryArr = res.data;
    })
  }

  getCourseByCategoryClg() {
    this.CompareclgService.getCourseByCategoryClg(this.predictAdmForm.value.course_category, this.collegeid).subscribe(res => {
      // console.log(res);
      this.CoursesByCatArr = res.data

    })
  }
  close() {
    this.dialog.closeAll();
  }

  savPredictAdmission() {
    if (this.predictAdmForm.invalid) {
      this.predictAdmForm.markAllAsTouched();
      return
    }
    if (this.predictAdmForm.valid) {
      this.CompareclgService.savPredictAdmission(
        this.predictAdmForm.controls.name.value,
        this.predictAdmForm.controls.email.value,
        this.predictAdmForm.controls.mobileno.value,
        this.predictAdmForm.controls.course_category.value,
        this.collegeid,
        this.predictAdmForm.controls.course.value,
        this.predictAdmForm.controls.exam.value,
        this.predictAdmForm.controls.expected_rank.value,
        this.predictAdmForm.controls.expected_score.value,
      ).subscribe(res => {
        console.log(res);
        this.close();
      })
    }
  }

  getExamList() {
    // this.ExamLoader = true;
    this.CompareclgService.getExamList('').subscribe(res => {
      // console.log(res);
      // this.ExamLoader = false;
      this.examListArr = res.response_data;
    })
  }

  downloadBrochure(collegeid) {
    // alert(7878787878787)
    if (!this.authService.isLoggedIn()) {
      this.LoginpopupService.openLoginPopup();
    }
    else {
      this.CompareclgService.downloadBrochure(collegeid, '1').subscribe(res => {
        console.log(res);
        Swal.fire(res.response_message);
      })
    }
  }

  getRatingList() {
    this.CompareclgService.getRatingList().subscribe(res => {
      console.log(res)
      this.RatingArr = res.Rating;
    })
  }
}
