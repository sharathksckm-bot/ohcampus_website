import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';
import { param } from 'jquery';

@Component({
  selector: 'app-examdetails',
  templateUrl: './examdetails.component.html',
  styleUrls: ['./examdetails.component.scss']
})
export class ExamdetailsComponent implements OnInit {
  ExamId: any;
  examName: any;
  examImage: any;
  examCateegory: any;
  examdescription: any;
  examCriteria: any;
  exampattern: any;
  examprocess: any;
  relatedExamsArr: any = [];
  // fillArray:any=[];
  numSlides: number;
  ExamLoader: boolean = false;


  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,) {
    this.numSlides = Math.ceil(this.relatedExamsArr.length / 3);
  }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    // console.log(routeParams);
    this.ExamId = routeParams.examid;
    this.getExamDetails();

  }

  getExamDetails() {
    this.ExamLoader = true;
    this.CompareclgService.getExamDetails(this.ExamId).subscribe(res => {
      // console.log(res);
      this.ExamLoader = false;
      this.examName = res.examdetails[0].title;
      this.examImage = res.examdetails[0].image;
      this.examCateegory = res.examdetails[0].catname;
      this.examdescription = res.examdetails[0].description;
      this.examCriteria = res.examdetails[0].criteria;
      this.examprocess = res.examdetails[0].process;
      this.exampattern = res.examdetails[0].pattern;
      this.relatedExamsArr = res.relatedExams;
      // this.fillArray=Math.ceil(this.relatedExamsArr.length / 3);
      // console.log(this.fillArray)
    })
  }


  get numSlidesArray(): number[] {
    return Array(this.numSlides).fill(0).map((x, i) => i + 1);
  }
}
