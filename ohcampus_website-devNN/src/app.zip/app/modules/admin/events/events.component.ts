import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss']
})
export class EventsComponent implements OnInit {
  SearchForm: FormGroup;

  eventsArr: any = [];
  itemsToShow: number = 10;
  ArticlesToShow: number = 10;
  activeTabIndex: number = 0;
  activeTab: string;
  EventLoader: boolean = false;
  ArticleLoader: boolean = false;
  // showShare:boolean=false;
  showShare: boolean[] = [];
  searchCategory = '';
  notification: any;
  searchevent: any;


  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,
  ) {
    this.eventsArr.forEach(() => {
      this.showShare.push(false);
    });
  }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    console.log(routeParams);
    this.searchevent = routeParams.searchevent
    this.SearchForm = this._formBuilder.group({
      searchtext: ['']
    })
    // this.getEvents();
    if (this.searchevent != undefined) {
      this.getEvent();
    }
    if (this.searchevent == undefined) {
      this.getEvents();
    }
  }

  //get Events 
  getEvents() {
    this.EventLoader = true;
    this.CompareclgService.getEvents(this.SearchForm.value.searchtext).subscribe(res => {
      this.EventLoader = false;
      this.eventsArr = res.response_data;
      // this.eventName = this.eventsArr[0].event_name;
      // this.eventImage = this.eventsArr[0].image;
      // this.eventStartDate = this.eventsArr[0].event_start_date;
      // this.eventEndDate = this.eventsArr[0].event_end_date;
    })
  }

  getEventDetails(event_id) {
    this.route.navigate(['/eventdetails', event_id])
  }

  toggleShare(index: number) {
    this.showShare[index] = !this.showShare[index];
  }

  showMoreEvents() {
    this.itemsToShow += 10;
  }

  searchEvent() {
    this.CompareclgService.getEvents(this.SearchForm.value.searchtext).subscribe(res => {
      this.EventLoader = false;
      this.eventsArr = res.response_data;
    })
  }

  getEvent() {
    this.CompareclgService.getEvents(this.searchevent).subscribe(res => {
      this.EventLoader = false;
      this.eventsArr = res.response_data;
    })
  }
}
