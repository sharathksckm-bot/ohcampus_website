import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompareclgService } from 'app/modules/service/compareclg.service';


@Component({
  selector: 'app-certifications',
  templateUrl: './certifications.component.html',
  styleUrls: ['./certifications.component.scss']
})
export class CertificationsComponent implements OnInit {
  certificateId: any;
  name: any;
  descritpion: any;
  image: any;

  constructor(
    public CompareclgService: CompareclgService,
    private _activatedRoute: ActivatedRoute,
    private route: Router,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,

  ) { }

  ngOnInit(): void {
    const routeParams = this._activatedRoute.snapshot.params;
    console.log(routeParams);
    this.certificateId=routeParams.certificateId;
    this.getCertificationDatabyId();
  }

  getCertificationDatabyId() {
    this.CompareclgService.getCertificationDatabyId(this.certificateId).subscribe(res => {
      console.log(res);
      this.name=res.certificateDetails.name;
      this.image=res.certificateDetails.image;
      this.descritpion=res.certificateDetails.descritpion;
    })
  }
}
