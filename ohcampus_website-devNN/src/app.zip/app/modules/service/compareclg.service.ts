import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class CompareclgService {
  apiurl = environment.apiurl;
  constructor(private _httpClient: HttpClient,) { }

  //get state list
  public getstateList(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}CompareCollege/getStateList`,
      {defaultToken : localStorage.getItem('defaultToken')}
    );
  }

  //get city list
  public getcityList(stateId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}CompareCollege/getCityList`,
      { stateId: stateId,defaultToken : localStorage.getItem('defaultToken') }
    );
  }

  //get course category
  public getCourseCatList(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}CompareCollege/getccList`,
      {defaultToken : localStorage.getItem('defaultToken')}
    );
  }

  //get course
  public getCourse(catid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}CompareCollege/getCourseList`,
      { catid: catid,defaultToken : localStorage.getItem('defaultToken') }
    );
  }


  ////------------ALL COLLEGES API'S-----------------////
  //get city
  public getCity(search_term): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}City/getCityList`,
      { search_term: search_term,defaultToken : localStorage.getItem('defaultToken')}
    );
  }

  //get rank
  public getRankList(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Rank/getRankList`,
      {defaultToken : localStorage.getItem('defaultToken')}
    );
  }

  //get city
  public getCourseList(search_term): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCoursesList`,
      { search_term: search_term,defaultToken : localStorage.getItem('defaultToken') }
    );
  }

  //get Ownership List
  public getOwnershipList(search_term): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCollegeType`,
      { search_term: search_term,defaultToken : localStorage.getItem('defaultToken'),
    }
    );
  }

  //get Ownership List
  public getCollegeList(draw, length, start, order, search): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCollegeList`,
      {
        // eslint-disable-next-line max-len
        defaultToken : localStorage.getItem('defaultToken'),
        draw: draw,
        length: length,
        start: start,
        order: order,
        search: search
          }
    );
  }

  public getCollegeList1(selected_rank_category, search_keyword): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Rank/getCollegeList`,
      {
        selected_rank_category: selected_rank_category,
        search_keyword: search_keyword
      }
    );
  }


  ///------------Home Page API'S------------------//
  //Total count
  public getTotalCount(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/getTotalCount`,
      {
        defaultToken : localStorage.getItem('defaultToken'),

      }
    );
  }

  //getFeaturedColleges
  public getFeaturedColleges(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getFeaturedColleges`,
      {
        defaultToken : localStorage.getItem('defaultToken'),

      }
    );
  }

  //getFeaturedColleges
  public getTrendingColleges(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getTrendingColleges`,
      { defaultToken : localStorage.getItem('defaultToken'),

      }
    );
  }

  //getevents
  public getEvents(value): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Event/getEventList`,
      { value:value,defaultToken : localStorage.getItem('defaultToken'),

      }
    );
  }

  //getCategory
  public getCategory(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Category/getCategory`,
      {defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  //getCategory
  public getCoursesByCatId(CatId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCoursesByCatId`,
      {
        CatId: CatId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }


  //Compare College page API
  //get college list for search
  public getCollegelistCompare(searchTerm, start, limit): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} CompareCollege/getCollegeList`,
      {
        searchTerm: searchTerm,
        start: start,
        limit: limit,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  //getDegreeData
  public getLevelById(Id): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} CompareCollege/getLevelById`,
      {
        Id: Id,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  //getCoursesListbyColleges
  public getCoursesbyCollege(level, Id): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} CompareCollege/getCoursesById`,
      {
        level: level,
        Id: Id,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  //getfeaturedcolleges
  public CompareCollege(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} CompareCollege/getFeaturedColleges`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  //getfeaturedcolleges
  public getCollegeDetailsByID(id): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} College/getCollegeDetailsByID`,
      {
        id: id,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  //getfeaturedcolleges
  public getcompareCollegeDetailsByID(id): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} CompareCollege/getCollegeDetailsByID`,
      {
        id: id,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCategoryForMenu(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} Category/getCategoryForMenu`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCategoryForMenuNav(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} Category/getCategoryForMenuNav`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCityList(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} City/getCity`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }
  public getCourseCategory(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} Courses/getCourseCategory`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  // public getCourseByCategory(categoryId): Observable<any> {
  //   return this._httpClient.post(
  //     `${this.apiurl} Courses/getCourseByCategory`,
  //     {
  //       categoryId: categoryId
  //     }
  //   );
  // }

  //05/04/024
  public getCourseByCategory(categoryId,search): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} Courses/getCourseByCategory`,
      {
        categoryId: categoryId,
        search:search,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }


  public getBlogs(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} Blogs/getBlogs`,
      {defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getBlogsbyCat(searchCategory,value): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl} Blogs/getBlogs`,
      {defaultToken : localStorage.getItem('defaultToken'),
        searchCategory: searchCategory,
        value:value
      }
    );
  }

  public getPlacementCategory(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Category/getPlacementCategory`,
      {defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getPlacementDataOfClg(searchYear, searchCategory, collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getPlacementDataOfClg`,
      {
        searchYear: searchYear,
        searchCategory: searchCategory,
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getExamNotificationForClg(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Exam/getExamNotificationForClg`,
      {
        collegeid: collegeid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getRanktDataOfClg(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getRanktDataOfClg`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCoursesAndFeesOfClg(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCoursesAndFeesOfClg`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getFAQsOfClg(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getFAQsOfClg`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCollegeProgrammesByID(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCollegeProgrammesByID`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public coursesOfferedInSameGroup(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/coursesOfferedInSameGroup`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCollegeContactDetails(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCollegeContactDetails`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getcollegeByLocation(cityid, collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getcollegeByLocation`,
      {
        cityid: cityid,
        collegeid: collegeid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCollegeAdmissionProcess(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCollegeAdmissionProcess`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCoursesOfCollege(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCoursesOfCollege`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCoursesOfCollegeFilter(collegeId, course, courselevel, total_fees, exam_accepted, course_name): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCoursesOfCollege`,
      {
        collegeId: collegeId,
        course: course,
        courselevel: courselevel,
        total_fees: total_fees,
        exam_accepted: exam_accepted,
        course_name: course_name,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getOtherCollegesOfferingSameCourseInSameCity(cityId,collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getOtherCollegesOfferingSameCourseInSameCity`,
      {
        cityId: cityId,
        collegeId:collegeId,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCoursesBySubcategory(collegeId, subcategory): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCoursesBySubcategory`,
      {
        collegeId: collegeId,
        subcategory: subcategory,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getLatestBlogs(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Blogs/getLatestBlogs`,
      {
        collegeid:collegeid,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getSubCategoryList(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/getSubCategoryList`,
      {
        collegeid: collegeid,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCourseLevel(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/getCourseLevel`,
      {
        collegeid: collegeid,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getExamAccepted(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/getExamAccepted`,
      {
        collegeid: collegeid,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getScholarShipOfClg(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getScholarShipOfClg`,
      {
        collegeId: collegeId,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCollegeHighlightByID(id): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCollegeHighlightByID`,
      {
        id: id,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getFeesDataOfCollege(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getFeesDataOfCollege`,
      {
        collegeId: collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getExamList(value): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Exam/getExamList`,
      {
        value: value,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCollegeListForCompare(searchClg): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCollegeListForCompare`,
      {
        searchClg: searchClg,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getExamDetails(examId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Exam/getExamDetails`,
      {
        examId: examId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getBlogsDetails(blogId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Blogs/getBlogsDetails`,
      {
        blogId: blogId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getBlogCategory(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Blogs/getBlogCategory`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public saveCourseInquiry(firstName, lastName, email, phone, courseCategory, course, intrestedIn): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/saveCourseInquiry`,
      {
        firstName: firstName,
        lastName: lastName,
        email: email,
        phone: phone,
        courseCategory: courseCategory,
        course: course,
        intrestedIn: intrestedIn,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getUnAnsweredQueofCollege(length, draw, collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/getUnAnsweredQueofCollege`,
      {
        length: length,
        draw: draw,
        collegeid: collegeid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getQAofCollege(length, draw, collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/getQAofCollege`,
      {
        length: length,
        draw: draw,
        collegeid: collegeid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getQADataByQueId(collegeId, QueId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/getQADataByQueId`,
      {
        collegeId: collegeId,
        QueId: QueId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public postQuestion(collegeid, courselevel, course, user_id, questionInput): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/postQuestion`,
      {
        collegeid: collegeid,
        courselevel: courselevel,
        course: course,
        user_id: user_id,
        questionInput: questionInput,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public postAnswere(answer, user_id, questionId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/postAnswere`,
      {
        answer: answer,
        user_id: user_id,
        questionId: questionId,defaultToken : localStorage.getItem('defaultToken')

      }
    );
  }

  public postAnsComment(comment, user_id, answer_id): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/postAnsComment`,
      {
        comment: comment,
        user_id: user_id,
        answer_id: answer_id,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public followQuestion(action, user_id, question_id): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/followQuestion`,
      {
        action: action,
        user_id: user_id,
        question_id: question_id,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public voteAnswere(action, answer_id, user_id): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/voteAnswere`,
      {
        action: action,
        answer_id: answer_id,
        user_id: user_id,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public saveEnquiry(name, email, phone, message, postid, type): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/saveEnquiry`,
      {
        name: name,
        email: email,
        phone: phone,
        message: message,
        postid: postid,
        type: type,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getPopularClgByLocation(cityid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getPopularClgByLocation`,
      {
        cityid: cityid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getEventDetails(eventid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Event/getEventDetails`,
      {
        eventid: eventid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }


  public getCollegesAccordingCategory(collegeid, categories): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getCollegesAccordingCategory`,
      {
        collegeid: collegeid,
        categories: categories,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getTotalQuestionForCollege(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/getTotalQuestionForCollege`,
      {
        collegeid: collegeid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getQueAnsAboutAdmissions(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/getQueAnsAboutAdmissions`,
      {
        collegeid: collegeid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }


  public getReviewDetails(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Review/getReviewDetails`,
      {
        collegeid: collegeid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCollegeTotalRate(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Review/getCollegeTotalRate`,
      {
        collegeid: collegeid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public voteReview(user_id, reviewid, ishelpful): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Review/voteReview`,
      {
        user_id: user_id,
        reviewid: reviewid,
        ishelpful: ishelpful,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public addReview(
    user_id,
    collegeid,
    courtype,
    courseid,
    title,
    placement_rate,
    placement_description,
    infrastructure_rate,
    infrastructure_description,
    faculty_rate,
    faculty_description,
    hostel_rate,
    hostel_description,
    campus_rate,
    campus_description,
    money_rate,
    money_description
    ): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Review/addReview`,
      {
        user_id: user_id,
        collegeid: collegeid,
        courtype: courtype,
        courseid: courseid,
        title: title,
        placement_rate: placement_rate,
        placement_description: placement_description,
        infrastructure_rate: infrastructure_rate,
        infrastructure_description:infrastructure_description,
        faculty_rate:faculty_rate,
        faculty_description:faculty_description,
        hostel_rate:hostel_rate,
        hostel_description:hostel_description,
        campus_rate:campus_rate,
        campus_description:campus_description,
        money_rate:money_rate,
        money_description:money_description,
        defaultToken : localStorage.getItem('defaultToken'),
      }
    );
  }

  public downloadBrochure(collegeId,userId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/downloadBrochure`,
      {
        collegeId: collegeId,
        userId:userId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public savCourseApplication(student_name,email,mobile_no,category,college,course,entrance_exam,rank,score): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/savCourseApplication`,
      {
        student_name: student_name,
        email:email,
        mobile_no:mobile_no,
        category:category,
        college:college,
        course:course,
        entrance_exam:entrance_exam,
        rank:rank,
        score:score,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public savPredictAdmission(student_name,email,mobile_no,category,college,course,entrance_exam,rank,score): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/savPredictAdmission`,
      {
        student_name: student_name,
        email:email,
        mobile_no:mobile_no,
        category:category,
        college:college,
        course:course,
        entrance_exam:entrance_exam,
        rank:rank,
        score:score,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }


  public getCourseByCategoryClg(categoryId,collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCourseByCategoryClg`,
      {
        categoryId: categoryId,
        collegeId:collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

//homepage getTrendingSpecilization
  public getTrendingSpecilization(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/getTrendingSpecilization`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getlistofCertificate(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Certification/getlistofCertificate`,
      {defaultToken : localStorage.getItem('defaultToken')

      }
    );
  }

  public getAllCourseList(draw, length, start, order, search): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCourseList`,
      {
        draw: draw,
        length: length,
        start: start,
        order: order,
        search: search,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }


  public getCertificationDatabyId(certificateId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Certification/getCertificationDatabyId`,
      {
        certificateId:certificateId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public sendContactMail(name,email,contactNo,subject,message): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Common/sendContactMail`,
      {
        name:name,
        email:email,
        contactNo:contactNo,
        subject:subject,
        message:message,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getScholarships(search): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Scholarship/getScholarships`,
      {
        search:search,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getLoans(search): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Loan/getLoans`,
      {
        search:search,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getFaqCategory(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Faq/getFaqCategory`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getFaqs(search,category): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Faq/getFaqs`,
      {
        search:search,
        category:category,
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCoursesFeeStructure(courseid,collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCoursesFeeStructure`,
      {
        courseid:courseid,
        collegeId:collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCoursesInfo(courseid,collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCoursesInfo`,
      {
        courseid:courseid,
        collegeId:collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getCoursesAdmissionProcess(courseid,collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getCoursesAdmissionProcess`,
      {
        courseid:courseid,
        collegeId:collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getQueAnsAboutCourses(collegeid,courseid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/getQueAnsAboutCourses`,
      {
        collegeid:collegeid,
        courseid:courseid,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getEntranceExamsForCourse(courseid,collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Courses/getEntranceExamsForCourse`,
      {
        courseid:courseid,
        collegeId:collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public collegesOffereingSameCourseAtSameCity(courseid,cityid,collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/collegesOffereingSameCourseAtSameCity`,
      {
        courseid:courseid,
        cityid:cityid,
        collegeId:collegeId,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public AdmissionProcessImportantDatesPDF(collegeId,sub_category): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/AdmissionProcessImportantDatesPDF`,
      {
        collegeId:collegeId,
        sub_category:sub_category,defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }

  public getLastThreeYearsPlacementData(collegeId): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}College/getLastThreeYearsPlacementData`,
      {
        collegeId:collegeId,defaultToken : localStorage.getItem('defaultToken')

      }
    );
  }

  public getPlacementRating(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Review/getPlacementRating`,
      {
        collegeid:collegeid,defaultToken : localStorage.getItem('defaultToken')

      }
    );
  }

  public getInfrastructureRating(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Review/getInfrastructureRating`,
      {
        collegeid:collegeid,defaultToken : localStorage.getItem('defaultToken')

      }
    );
  }

  public getQueAnsAboutScholarships(collegeid): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}QuestionAnswere/getQueAnsAboutScholarships`,
      {
        collegeid:collegeid,defaultToken : localStorage.getItem('defaultToken')

      }
    );
  }

  public getRatingList(): Observable<any> {
    return this._httpClient.post(
      `${this.apiurl}Review/getRatingList`,
      {
        defaultToken : localStorage.getItem('defaultToken')
      }
    );
  }



  private apiKey = 'AIzaSyAMybtct7fx4uCZyrxiZ_ykI0cSihTjINg';
  getPlaceReviews(placeId: string): Observable<any> {
    const proxyUrl = 'https://cors-anywhere.herokuapp.com/';
    const apiUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=name,reviews&key=${this.apiKey}`;
    const url = proxyUrl + apiUrl;

    return this._httpClient.get<any>(url).pipe(
      catchError((error: HttpErrorResponse) => {
        let errorMessage = 'Unknown error occurred';
        if (error.error instanceof ErrorEvent) {
          // Client-side error
          errorMessage = `Error: ${error.error.message}`;
        } else {
          // Server-side error
          errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
      })
    );
  }

}
