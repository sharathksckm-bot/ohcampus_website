import { Component, OnDestroy, OnInit, ViewEncapsulation, ViewChild, TemplateRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FuseAlertType } from '@fuse/components/alert';
import { LoginpopupService } from 'app/shared/loginpopup.service';
import { AuthService } from 'app/core/auth/auth.service';
import { takeUntil } from 'rxjs/operators';
import { FuseNavigationService, FuseVerticalNavigationComponent } from '@fuse/components/navigation';
import { Navigation } from 'app/core/navigation/navigation.types';
import { NavigationService } from 'app/core/navigation/navigation.service';
import { MatDialog } from '@angular/material/dialog';
import { Subject } from 'rxjs';
import { FuseMediaWatcherService } from '@fuse/services/media-watcher';
// import { CompareclgService } from 'app/modules/service/compareclg.service';

function passwordMatchValidator(password: string): ValidatorFn {
    return (control: FormControl) => {
        // console.log(control)
        if (!control || !control.parent) {
            return null;
        }
        return control.parent.get(password).value === control.value ? null : { mismatch: true };
    };
}
@Component({
  selector: 'app-loginpopup',
  templateUrl: './loginpopup.component.html',
  styleUrls: ['./loginpopup.component.scss']
})
export class LoginpopupComponent implements OnInit {
  @ViewChild('signInNgForm') signInNgForm: NgForm;
  @ViewChild('signUpNgForm') signUpNgForm: NgForm;
  @ViewChild('callsignInForm') callsignInForm: TemplateRef<any>;

  alert: { type: FuseAlertType; message: string } = {
    type: 'success',
    message: ''
  };

  signInForm: FormGroup;
  showLoginPopup: boolean = false;
  showAlert: boolean = false;
  showSignIn: boolean = true;
  showSignUp: boolean = false;
  signUpForm: FormGroup;
  isOtpSent: boolean = false;
  // eslint-disable-next-line @typescript-eslint/naming-convention
  // OTP: boolean = true;
  isScreenSmall: boolean;
  navigation: Navigation;
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  // eslint-disable-next-line @typescript-eslint/member-ordering
  isDataSubmit: boolean = true;
    router: any;

  constructor(private LoginpopupService: LoginpopupService,
    private _activatedRoute: ActivatedRoute,
    private _router: Router,
    private _formBuilder: FormBuilder,
    private _navigationService: NavigationService,
    private _fuseMediaWatcherService: FuseMediaWatcherService,
    private _fuseNavigationService: FuseNavigationService,
    public dialog: MatDialog,
    private _authService: AuthService,
    // private CompareclgService: CompareclgService
  ) { }

  ngOnInit(): void {
    this.LoginpopupService.showLoginPopup$.subscribe((showPopup) => {
      this.showLoginPopup = showPopup;
    });
    this.signInForm = this._formBuilder.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required],
        mobile_no: [''],
        rememberMe: ['']
    });
    this.signUpForm = this._formBuilder.group({
        name: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: ['', Validators.required],
        confirmpassword: ['', [Validators.required, passwordMatchValidator('password')]],
        // company: [''],
        mobile_no: [''],
        agreements: ['', Validators.requiredTrue],
        Otp: [''],

    }
    );
    // Subscribe to navigation data
    this._navigationService.navigation$
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe((navigation: Navigation) => {
            this.navigation = navigation;
        });

    // Subscribe to media changes
    this._fuseMediaWatcherService.onMediaChange$
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe(({ matchingAliases }) => {

            // Check if the screen is small
            this.isScreenSmall = !matchingAliases.includes('md');
        });
  }

  closeLoginPopup(): void {
    this.LoginpopupService.closeLoginPopup();
  }

signIn(): void {

    // Return if the form is invalid
    if (this.signInForm.invalid) {
        return;
    }

    // Disable the form
    this.signInForm.disable();

    // Hide the alert
    this.showAlert = false;
    // this._authService.logindata(this.signInForm.value.email, this.signInForm.value.password).subscribe(res => {
    //     console.log(res);
    // })
    // Sign in
    this._authService.logindata(this.signInForm.value.email, this.signInForm.value.password)
    .subscribe(
      (res) => {
        console.log('login response', res);
        const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/home';
        this._router.navigateByUrl(redirectURL);
        localStorage.setItem('username', this.signInForm.value.email);

        if (res.response_code == 200) {
            this.showLoginPopup = false;

          // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
           this._router.routeReuseStrategy.shouldReuseRoute = () => false;
          const currentUrl =  this._router.url + '?';
           this._router.navigateByUrl(currentUrl)
            .then(() => {
               this._router.navigated = false;
               this._router.navigate([ this._router.url]);
            });
        } else if (res.response_code == 2 || res.response_code == 3) {
          this.signInForm.enable();
          this.signInNgForm.resetForm();
          this.alert = {
            type: 'error',
            message: 'Wrong email or password '
          };
          this.showAlert = true;
        }
      },
      (error) => {
        alert('error');
        console.log(error);
        // Set the alert
        this.showAlert = true;
        this.alert = {
          type: 'error',
          message: error
        };
      }
    );

}
  //--------------------only Numbers are allowed---------------------//
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  showsign() {
    this.dialog.open(this.callsignInForm);
    this.showSignUp = false;
    this.showSignIn = true;
}

signinclose() {
    this.dialog.closeAll();
}

sign_up() {
    this.showSignUp = true;
    this.showSignIn = false;
}
sign_in() {
    this.showSignUp = false;
    this.showSignIn = true;
}
showsignup() {
    this.dialog.open(this.callsignInForm);
    this.showSignUp = true;
    this.showSignIn = false;
}

sendOtp() {
    this.isOtpSent = true;
    this.isDataSubmit = false;

}
  signUp(): void {
    // Do nothing if the form is invalid
    if (this.signUpForm.invalid) {
        return;
    }

    // Disable the form
    // this.signUpForm.disable();

    // Hide the alert
    this.showAlert = false;

    // Sign up
    this._authService.signUp(this.signUpForm.value)
        .subscribe(

            (response) => {
                // Navigate to the confirmation required page
                console.log(response);
                if (response.response_code == 400) {
                    // alert(67845);
                    this.signUpForm.enable();

                    // Reset the form
                    this.signUpNgForm.resetForm();

                    // Set the alert
                    this.alert = {
                        type: 'error',
                        message: 'Something went wrong, please try again. '
                    };

                    // Show the alert
                    this.showAlert = true;
                }
                if (response.response_code == 300) {
                    // Reset the form
                    this.signUpNgForm.resetForm();
                    this.showAlert = true;
                    this.signUpForm.enable();

                    // Set the alert
                    this.alert = {
                        type: 'error',
                        message: response.response_message
                    };
                }

                if (response.response_code == 200) {
                    this.isOtpSent = true;
                    this.isDataSubmit = false;
                    // this.showSignUp = false;
                    // this.showSignIn = true;
                    this.showAlert = true;
                    this.alert = {
                        type: 'success',
                        message: response.response_message
                    };

                }

                // else {
                //     this._router.navigateByUrl('/confirmation-required');
                // }

            },
            // (response) => {

            //     // Re-enable the form
            //     this.signUpForm.enable();

            //     // Reset the form
            //     this.signUpNgForm.resetForm();

            //     // Set the alert
            //     this.alert = {
            //         type: 'error',
            //         message: 'Something went wrong, please try again.'
            //     };

            //     // Show the alert
            //     this.showAlert = true;
            // }
        );
}

verifyOTP(): void {
    this._authService.verifyOTP(this.signUpForm.value)
        .subscribe(
            (response) => {
                console.log(response);
                if (response.response_code == 200) {
                    this.showSignUp = false;
                    this.showSignIn = true;
                    this.showAlert = true;
                    this.alert = {
                        type: 'success',
                        message: response.response_message
                    };

                }
                else
                {
                    this.showAlert = true;
                    this.alert = {
                        type: 'error',
                        message: response.response_message
                    };
                }
            },
            (error) => {
                this.showAlert = true;
                    this.alert = {
                        type: 'error',
                        message: error
                    };
            }
        );
}

}
