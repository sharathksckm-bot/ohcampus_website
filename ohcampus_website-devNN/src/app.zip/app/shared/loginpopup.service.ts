import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginpopupService {
  private showLoginPopupSource = new Subject<boolean>();
  showLoginPopup$ = this.showLoginPopupSource.asObservable();

  constructor() {}

  openLoginPopup(): void {
    this.showLoginPopupSource.next(true);
  }

  closeLoginPopup(): void {
    this.showLoginPopupSource.next(false);
  }
}
