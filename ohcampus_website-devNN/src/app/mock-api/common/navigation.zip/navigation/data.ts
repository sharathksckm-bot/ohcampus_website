/* tslint:disable:max-line-length */
import { FuseNavigationItem } from '@fuse/components/navigation';

export const defaultNavigation: FuseNavigationItem[] = [
    {
        id   : 'example',
        title: 'Example',
        type : 'basic',
        icon : 'heroicons_outline:chart-pie',
        link : '/example'
    }
];
export const compactNavigation: FuseNavigationItem[] = [
    {
        id   : 'example',
        title: 'Example',
        type : 'basic',
        icon : 'heroicons_outline:chart-pie',
        link : '/example'
    }
];
export const futuristicNavigation: FuseNavigationItem[] = [
    {
        id   : 'example',
        title: 'Example',
        type : 'basic',
        icon : 'heroicons_outline:chart-pie',
        link : '/example'
    }
];
export const horizontalNavigation: FuseNavigationItem[] = [
    // {
    //     id   : 'example',
    //     title: 'Example',
    //     type : 'basic',
    //     icon : 'heroicons_outline:chart-pie',
    //     link : '/example'
    // },
    // {
    //     id   : 'home',
    //     title: 'Home',
    //     type : 'basic',
    //     icon : 'heroicons_outline:home',
    //     link : '/home'
    // },
    // {
    //     title: 'Compare College',
    //     type : 'basic',
    //     icon : 'mat_outline:apartment',
    //     link : '/comparecollege'
    // },
    // {
    //     title: 'College List',
    //     type : 'basic',
    //     icon : 'mat_outline:apartment',
    //     link : '/comparison'
    // }
    
    
];
